# Data Riset Tambahan 5 / Stage 9.5

Tanggal cut-off 2026-10-24. Modul independen untuk integrasi ke arsip besar Indonesia–Singapura. File CSV UTF-8 BOM supaya mudah dibaca Excel Indonesia, dengan kolom source_url untuk audit.

Hindari penjumlahan kategori bertumpang tindih. Tahun 2023 S$127.6m foundation sudah mencakup NUS S$101m. Tahun 2025 NUS/NTU tidak menjadi angka tahunan 'realisasi'; donor pribadi, yayasan, perusahaan tiga entitas berbeda.

CSV: donation_commitment_ledger.csv, company_social_annual.csv, education_ppm_annual.csv, beneficiary_outcomes.csv, source_registry.csv, data_gaps_and_requests.csv.
Laporan utama: RESEARCH_REPORT.md. Workbook: Kalcer_Filantropi_Low_Indonesia_Singapura_Audit_2019_2026.xlsx. Validasi checksum: MANIFEST_SHA256.csv.
