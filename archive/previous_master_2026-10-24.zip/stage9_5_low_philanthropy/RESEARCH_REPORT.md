# KALCER INVESTIGATION — RISET TAMBAHAN 5 / TAHAP 9.5
## Audit filantropi Low Tuck Kwong, yayasan Singapura, dan Bayan Resources di Indonesia
**Cut-off data:** 24 Oktober 2026 (WIB). **Fokus:** komitmen, pengeluaran tahunan, negara institusi penerima, warga penerima manfaat, dan risiko menghitung ganda.

### EXECUTIVE FINDINGS
1. **Low Tuck Kwong pribadi** menyumbang Rp100 miliar kepada ITB (2019), Rp50 miliar kepada UGM (2020), Rp50 miliar kepada UI (2021): **Rp200 miliar** dana pendidikan perguruan tinggi di Indonesia. UI/UGM berfungsi dana abadi; ITB membiayai beasiswa serta pembangunan Labtek XVII yang diresmikan 2024. Pengumuman dari universitas penerima merupakan bukti primer. Pengaliran uang secara rinci per rekening bukan data publik. [S01-S06]
2. **Low Tuck Kwong Foundation**: NUS menerima hibah **S$101 juta** pada Feb 2023 untuk kebijakan publik, kepemimpinan Asia, serta beasiswa mahasiswa berbagai negara termasuk Indonesia. NTU mengumumkan **janji donasi S$8 juta** pada Mar 2025, terdiri atas S$6 juta bantuan mahasiswa Singapura dan S$2 juta beasiswa mahasiswa Indonesia untuk pendidikan magister di NTU. **S$109 juta adalah nominal hibah/gift dan pledge yang diumumkan pada dua kampus**, bukan total disbursement tahunan yang telah diaudit. [S07-S09]
3. Kompilasi Soristic mencatat **S$127,6 juta** hibah Low Tuck Kwong Foundation tahun 2023 dan **S$23,2 juta** tahun 2024. **S$150,8 juta untuk dua tahun itu**, mencakup pendidikan, kesehatan dan kesejahteraan, di Singapura maupun kawasan. S$101 juta NUS **termasuk** dalam S$127,6 juta; 2025 NTU pledge tidak termasuk total itu. Angka agregat bukan seluruhnya diterima warga Singapura. Soristic memperingatkan bahwa dalam kasus tertentu *commitments* dijadikan proksi untuk disbursements. [S10-S11]
4. Bayan Resources secara korporat melaporkan pengeluaran 2022 Rp40,70 miliar, 2023 Rp89,8 miliar, 2024 Rp124,8 miliar, 2025 Rp223,9 miliar (jumlah **Rp479,2 miliar**). Tahun 2022 didefinisikan 'pengembangan masyarakat'; 2023–2025 menekankan PPM dan Bayan Peduli. Seri laporan antar-tahun tidak pasti dapat diperbandingkan langsung karena cakupan kegiatan berubah. [S13-S16]
5. **Alokasi pendidikan PPM wilayah operasi:** 2022 Rp6,02 miliar; 2023 Rp5,9 miliar; 2024 Rp7,5 miliar; 2025 Rp14,1 miliar — total **Rp33,52 miliar**. Kategori ini lebih sempit dari seluruh pendidikan nasional Bayan Peduli dan lebih sempit dari seluruh Rp479,2 miliar pengeluaran sosial. [S13-S16]
6. Bayan Peduli mengumumkan **komitmen Rp19,7 miliar untuk empat tahun akademik** mulai 2022/23 melalui UNIKARTA/UNIBA, dan indikator kumulatif **Rp119,6 miliar beasiswa, 4.000+ mahasiswa, 14 universitas** pada situs program. Rp19,7 miliar dan Rp119,6 miliar serta pengeluaran perusahaan tahunan **belum dapat dinyatakan aditif**, karena kemungkinan cakupan dan periode bertumpang tindih. Laporan 2025 menyebut **2.334 mahasiswa** mendapatkan akses melanjutkan pendidikan pada TA 2025/26; jumlah penerima antar-tahun juga bisa berulang. [S16-S18]
7. **Tidak dapat dihitung persentase manfaat Indonesia versus Singapura secara valid** tanpa daftar grant tahunan keluarga/yayasan secara lengkap, jadwal realisasi, pengelompokan geografis penerima manfaat, dan eliminasi transaksi bertumpuk. Yayasan juga menyebut UTAR Hospital Fund (Malaysia) dan program SGH (Singapura), nilainya belum terungkap. [S12]
8. **Koreksi data lama:** nilai Rp80,67 miliar yang pernah disebut sebagai total sosial Bayan 2025 tidak cocok dengan total Rp223,9 miliar dalam laporan keberlanjutan primer 2025. Jangan gunakan angka Rp80,67 miliar sebagai total PPM+Bayan Peduli tanpa rekonsiliasi.

### CATATAN PENTING UNTUK KORSEL
- **Fakta kuat**: institusi pendidikan Singapura menerima satu donasi NUS S$101 juta dan satu pledge NTU S$8 juta. Pada sisi Indonesia terdapat donasi pribadi Rp200 miliar kepada tiga PTN, program beasiswa perusahaan di Kalimantan dan nasional, serta pengeluaran PPM pendidikan Rp33,52 miliar selama 2022–2025.
- **Kritik kebijakan yang dapat diuji**: apakah alokasi kepada institusi pendidikan Singapura yang lebih maju sebanding dengan kebutuhan dan hasil belajar anak-anak di daerah penghasil batu bara? Untuk menjawab, perlu alokasi *per beneficiary*, bukan sekadar memotret gedung dan membandingkan angka yang berbeda definisi.
- **Tidak layak sebagai klaim faktual**: bahwa seluruh S$150,8 juta 'menyejahterakan warga Singapura'; bahwa Low sama sekali tidak berdonasi ke Indonesia; bahwa Rp14,1 miliar PPM adalah seluruh dana pendidikan Bayan 2025; bahwa donasi NUS dibayar langsung dari dividen BYAN kepada rekening Singapura.
- **Perbaikan narasi**: bedakan 'di mana dana ditempatkan secara institusional', 'siapa penerima beasiswa yang sebenarnya', dan 'siapa pemilik/manajer manfaat jangka panjang atas dana abadi'.

### PRIORITAS VERIFIKASI
1. Laporan audit dan daftar penerima dana Low Tuck Kwong Foundation FY2023-2025 per negara & kategori. Soristic FY2023/FY2024 bersifat agregat.
2. Pernyataan cash received dan syarat pengelolaan endowment NUS/NTU; jadwal pencairan dana dan *matching grant* bila ada.
3. Data BPPM / Bayan Peduli realisasi pengeluaran pendidikan 2022-2025 dan pembagiannya Kutai Kartanegara/Kutai Timur/Kutai Barat versus nasional.
4. Bukti komitmen tambahan Low/PYC/Yayasan untuk Indonesia sesudah 2021.
5. Dampak penerima siswa sekitar tambang (jumlah unik, kelulusan, kualitas sekolah, biaya per siswa).
6. Struktur sumber dana foundation, bila dinyatakan publik; saat ini belum ada bukti dividen BYAN secara langsung menjadi dana yayasan Singapura.

### DEFINISI DATASET
- `donation_commitment_ledger.csv`: per hibah atau publikasi agregat; gunakan counting_rule untuk menghindari double count.
- `company_social_annual.csv`: total pengeluaran sosial Bayan menurut definisi tiap laporan; bukan dana pribadi Low.
- `education_ppm_annual.csv`: alokasi khusus pendidikan PPM per laporan, subset dari pengeluaran sosial.
- `beneficiary_outcomes.csv`: angka siswa dan penerima yang belum tentu unik antar-tahun.
- `source_registry.csv`: sumber primer dan sumber agregasi yang digunakan.
- `data_gaps_and_requests.csv`: permintaan untuk verifikasi lanjutan.
- `validation_checks.json`: pemeriksaan jumlah agregat dan non-additivity.

### PENYEBUTAN NILAI DALAM RUPIAH
Perbandingan kurs SGD/IDR sebaiknya menggunakan kurs historis tanggal pengumuman masing-masing, dan diberi label 'ekuivalensi indikatif'. Karena S$109 juta meliputi donasi di dua tanggal berbeda serta janji pembayaran bertahap, jangan gunakan satu kurs spot 2026 sebagai nilai pembayaran historis.

### REFERENSI PRIMER
- [S01] ITB official 2020 scholarship announcement — https://itb.ac.id/berita/itb-luncurkan-program-beasiswa-dan-penyerahan-beasiswa-dari-dato-low-tuck-kwong-dan-purnomo-yusgiantoro-center/57672
- [S02] ITB official 2024 Labtek XVII opening — https://itb.ac.id/berita/itb-dan-pyc-resmikan-gedung-labtek-xvii-dato-dr-low-tuck-kwong-siap-tingkatkan-riset-energi-masa-depan/61697
- [S03] UGM official 2020 endowment — https://ugm.ac.id/id/berita/20523-ugm-terima-dana-abadi-untuk-beasiswa-pendidikan/
- [S04] UGM official 2021 scholarship outcomes — https://ugm.ac.id/id/berita/21695-ugm-luncurkan-beasiswa-dato-dr-low-tuck-kwong-pyc/
- [S05] UI FEB official 2021 endowment — https://feb.ui.ac.id/2021/10/22/dato-dr-low-tuck-kwong-donasikan-50-miliar-untuk-beasiswa-universitas-indonesia/
- [S06] ANTARA clarification 2022 — https://www.antaranews.com/berita/2879001/perusahaan-batubara-klarifikasi-bantuan-dana-ratusan-miliar-bukan-csr
- [S07] NUS official gift announcement 2023 — https://news.nus.edu.sg/lee-kuan-yew-school-of-public-policy-sets-up-new-fund-and-scholarship-through-generous-s101m-gift-from-the-low-tuck-kwong-foundation/
- [S08] NTU official pledge 2025 — https://www.ntu.edu.sg/giving/news-and-stories/detail/low-tuck-kwong-foundation-gifts-sgd8-million-to-enhance-accessible-education-and-develop-talent
- [S09] NTU full 2025 press release — https://www.ntu.edu.sg/docs/default-source/corporate-ntu/hub-news/ntu-singapore-boosts-accessible-education-and-global-talent-development-with-sgd8-million-gift-from-low-tuck-kwong-foundation.pdf?sfvrsn=6794c5c_1
- [S10] Soristic 2024 largest philanthropic organisations — https://charityguidepoint.sg/singapores-biggest-philanthropic-organisations-2024/
- [S11] Soristic 2025 largest philanthropic organisations — https://soristic.asia/publication/singapores-biggest-philanthropic-organisations-2025/
- [S12] LTK Foundation official website — https://ltkfoundation.org/
- [S13] Bayan sustainability report 2022 p46 p107 — https://www.bayan.com.sg/cfind/source/files/sr-2022-byan-final.pdf
- [S14] Bayan sustainability report 2023 p46 p104 — https://www.bayan.com.sg/cfind/source/files/annual-report/sustanaibility-report/sr-bayan-2023-versi-complete_1.pdf
- [S15] Bayan sustainability report 2024 p46 p110 — https://www.bayan.com.sg/cfind/source/files/annual-report/sustanaibility-report/sr-byan-2024-final-ojk.pdf
- [S16] Bayan sustainability report 2025 p46 p114 p132 — https://www.bayan.com.sg/cfind/source/files/annual-report/sustanaibility-report/sustainability-report-byan-2025-ojk.pdf
- [S17] Bayan Peduli scholarship partnerships — https://bayanpeduli.bayan.com.sg/partnership
- [S18] Detik Bayan Peduli 2025 scholarships — https://news.detik.com/berita/d-8142919/tahun-ketiga-meraih-mimpi-bersama-beasiswa-pendidikan-bayan-peduli/amp
- [S19] NUS scholarship beneficiary profile — https://lkyspp.nus.edu.sg/giving/gift-impact
- [S20] NTU donated bursaries list — https://www.ntu.edu.sg/admissions/undergraduate/fees-and-funding/financial-aid/bursaries/list-of-donated-bursaries
- [S21] Bayan 2021 sustainability report — https://www.bayan.com.sg/cfind/source/files/bayan-resources-sr-2021.pdf
- [S22] UI Dana Abadi portal — https://sahabatmakara.ui.ac.id/visitors/dana-abadi
- [S23] Bayan corporate news 2023 — https://www.bayan.com.sg/ini-bentuk-kepedulian-bayan-terhadap-masyarakat-lingkungan

- [S24] The Foundry donor acknowledgements — https://foundry.sg/donate/ (LTK Foundation tercantum sebagai founding donor, nominal tidak dipublikasikan.)
