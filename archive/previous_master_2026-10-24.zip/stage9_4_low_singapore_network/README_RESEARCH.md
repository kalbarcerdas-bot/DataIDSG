# Riset 9.4 — Jejak Perusahaan Keluarga Low di Singapura

Cutoff 24 Oktober 2026 WIB. Disusun dari pengungkapan SGX dan Bayan, bukan penyelidikan rekening pribadi.

Berkas: `entities.csv` (entitas publik), `entity_relationship_edges.csv` (relasi dan as-of), `transaction_flow_ledger.csv` (aliran, fasilitas, biaya), `key_metrics.csv`, `source_registry.csv`, `data_gaps_and_requests.csv`, `RESEARCH_REPORT.md`, `validation_checks.json`.

Grade A = dokumen primer regulator/emiten; B = media yang mengutip disclosure; C = estimasi model yang harus ditandai. `status` membedakan `confirmed_received_by_seller`, biaya akrual, batas fasilitas, dan rencana pembayaran.

Pengalihan saham BYAN (tahap 9.3) dan dividen (9.2) tidak ditambahkan otomatis ke arus finansial Metis (9.4). Tidak tersedia bukti uang dividen BYAN masuk ke OCPL atau KaiYi.
