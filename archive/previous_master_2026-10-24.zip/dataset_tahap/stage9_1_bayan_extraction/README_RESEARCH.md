# KALCER | RISET TAMBAHAN 01 — EKSTRAKSI BATU BARA BAYAN (TAHAP 9.1)

**Dibangun:** 2026-10-24. **Periode:** tahun buku 2008–2025, semester I 2026.

## Ringkasan

- Produksi FY2008–FY2025 ~468,4 juta ton (estimasi dari angka tahunan yang dibulatkan; beberapa tahun sumber sekunder atau inkonsistensi pembulatan).
- Produksi FY2015–FY2025 ~384,0 juta ton pada seri angka ini; referensi tahap sebelumnya menyebut 383,9 juta ton karena pilihan pembulatan 2019 dan 2016. Jangan sajikan selisih 0,1 juta ton sebagai tambahan produksi nyata.
- Total pendapatan FY2011–FY2025 ~US$29,470 miliar, berdasarkan basis laporan historis dengan beberapa angka tepat tersumber dari data agregator cross-check.
- FY2008–FY2025 ~US$31,696 miliar PENDAPATAN KONSOLIDASI PROVISIONAL. Pendapatan FY2008–2009 belum tervalidasi terhadap audit primer, dan FY2010 terdapat restatement beda US$2,99 juta.
- Pendapatan bukan laba, laba bukan dividen, dan dividen bukan bukti aliran ke Singapura. Volume produksi tidak identik volume penjualan.
- Tahun 2022 total revenue US$4.703,6 juta; Tahun 2025 total revenue US$3.427,6 juta meski produksi lebih besar.
- 2025: laba konsolidasian US$784,051 juta vs laba pemegang saham induk US$767,916 juta.
- Laporan keuangan 2012 asli vs angka komparatif 2012 yang disajikan kembali dalam Annual Report 2013 mengandung selisih material: laba setahun +US$54,947 juta vs -US$13,748 juta. Perlu investigasi kebijakan akuntansi sebelum grafik laba multi-tahun dapat dianggap konsisten.
- Cash royalties 2025 US$263,453 juta; cash income tax paid US$320,755 juta; cash tax refunds US$358,597 juta; dividends to parent shareholders US$700 juta. Jangan campur cashflows dengan beban PPh akrual, royalti dalam COGS, dan setoran pajak pemerintah.

## Berkas
- `bayan_annual_panel_2008_2026H1.csv`: tabel panel tahunan (angka satuan tersedia di header). Baris H1 2026 **bukan setahun penuh**.
- `bayan_evidence_ledger.csv`: rekaman angkanya, unit, halaman sumber, dan keterbatasan.
- `bayan_source_registry.csv`: URL primer/sekunder dan klasifikasi asal.
- `bayan_reserve_snapshots.csv`: tiga titik estimasi cadangan dengan **tanggal basis berbeda**.
- `bayan_data_gaps.csv`: daftar audit lanjut dan prioritas.
- `bayan_summary_metrics.json`: metrik turunan untuk pipeline situs, tetap sertakan disclaimer.

## Aturan editorial

- **A**: dokumen primer atau salinannya (original perusahaan). **B**: dokumen media atau agregator; harus dibuktikan lebih lanjut.
- Pendapatan FY2008–2009 klasifikasi B; angka sumber sekunder **tidak untuk judul tanpa audit primer**.
- Estimasi cadangan JORC 2022 tidak boleh diberi label cadangan saat ini. Estimasi ini sudah mencakup faktor hukum, geologi dan ekonomi saat tanggal penyusunan.
- Perubahan besar nilai produksi harus dianalisis terhadap `coal_asp_usd_per_tonne`; pendapatan tidak sama dengan tonase × harga karena volume jual, penjualan nonbatu bara, dan penyesuaian lain.
- Provenance: sumber asli publik tersedia lewat URL; PDF bukan termasuk arsip ini. Daftar URL adalah audit trail, bukan klaim PDF telah disalin.
- Jika menambah data, gunakan satu titik sumber per angka dan pertahankan dokumen restatement (jangan menimpa nilai lama tanpa jejak).

## Agenda investigasi berikutnya

1. Unduh arsip audit 2008–2010 & 2014–2016 dari BEI/IDX/OJK atau cermin resmi yang masih aktif.
2. Rekonsiliasi 2012 perubahan laba FY2012 dengan komparatif FY2013.
3. Isikan `capex`, pajak dan royalti historis, serta produksi per konsesi.
4. Hubungkan ke modul perubahan kepemilikan/dividen untuk menjawab siapa yang mengekstrak manfaat finansial, di mana domisili pajaknya, dan siapa penerima akhir.
