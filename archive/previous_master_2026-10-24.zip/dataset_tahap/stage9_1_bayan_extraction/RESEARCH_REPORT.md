# KALCER INVESTIGATION — RISET TAMBAHAN 01 (TAHAP 9.1)

Tanggal penelitian: 24 Oktober 2026. Perusahaan: PT Bayan Resources Tbk (BYAN). Lingkup operasi perusahaan: tambang Kalimantan Timur dan Kalimantan Selatan; angka finansial dilaporkan pada tingkat konsolidasian grup, dan tidak boleh diatribusikan pada satu kabupaten.

## Pertanyaan penelitian

1. Berapa ton batu bara yang ditambang oleh Bayan sejak IPO 2008? 2. Berapa nilai penjualan dan laba yang timbul? 3. Berapa yang dibayarkan berupa pajak, royalti, investasi dan dividen? 4. Bagaimana memisahkan nilai yang diciptakan perusahaan, manfaat negara dan manfaat pemegang saham? Tahap 9.1 belum menghitung nilai yang diterima Low Tuck Kwong secara pribadi atau arus kas ke Singapura.

## Hasil tahap ini

| Metrik | Hasil indikatif | Catatan |
|:--|--:|:--|
| Produksi batu bara 2008–2025 | sekitar 468,4 juta ton | Penjumlahan volume produksi perusahaan yang dilaporkan secara membulat; tingkat keyakinan campuran A/B |
| Produksi 2015–2025 | sekitar 384,0 juta ton | Beda sekitar 0,1 Mt dari seri sebelumnya akibat angka pembulatan di tahun-tahun tertentu |
| Pendapatan konsolidasi 2008–2025 | sekitar US$31,696 miliar | PROVISIONAL: 2008–2009 dari sumber agregator, FY2010 menyimpan anomali angka sejarah |
| Pendapatan konsolidasi 2011–2025 | sekitar US$29,470 miliar | Basis angka utama untuk publikasi, perlu verifikasi lagi sumber tepat setiap tahun |
| Pendapatan konsolidasi 2015–2025 | sekitar US$24,562 miliar | Bukan nilai tambah PDRB ataupun laba |
| Akumulasi laba yang dapat diatribusikan kepada pemilik induk 2015–2025 | sekitar US$7,657 miliar | Nominal historis, sebagian data 2015–2020 dari agregator yang dibandingkan ringkasan perusahaan; jangan samakan dengan distribusi dividen |
| Produksi semester I/2026 | 32,9 juta ton | Tidak boleh dikalikan dua sebagai realisasi FY2026 |
| Pendapatan semester I/2026 | US$1.740,1 juta | Laporan interim 2026 |

## Temuan operasional

- Tahun 2025: produksi 68 juta ton, penjualan 70,8 juta ton, pendapatan US$3,428 miliar, laba berjalan grup US$784,051 juta, dan laba pemilik entitas induk US$767,916 juta. Perbedaan produksi dan penjualan dipengaruhi stok serta perdagangan batu bara.
- Tahun 2022: puncak pendapatan 2015–2025 sebesar US$4,704 miliar meski produksi hanya 38,9 juta ton; harga jual rata-rata jauh lebih tinggi ketimbang pada 2025.
- Proyek Tabang mulai menghasilkan pada 2014 dan menjadi motor utama kenaikan produksi; presentasi 2019 melaporkan kontribusi Tabang sekitar 79% dari produksi tahun 2018.
- 2025: capex menurut laporan manajemen US$178 juta. Arus kas pembayaran perolehan aset tetap US$165,404 juta. Dua indikator tidak boleh disamakan tanpa rekonsiliasi.
- 2025: pembayaran dividen kas pemegang saham entitas induk US$700 juta, di luar dividen minoritas US$2,932 juta.
- 2025: kas royalti/iuran produksi US$263,453 juta; pembayaran kas pajak penghasilan US$320,755 juta dan penerimaan restitusi US$358,597 juta. Ketiganya berbeda dengan angka beban PPh, beban royalti, atau total PNBP.
- Dalam tahun 2026, penyesuaian RKAB dan force majeure menunjukkan risiko kebijakan pada laju ekstraksi. Pada semester pertama produksi 32,9 juta ton. Jangan proyeksikan angka FY2026 tanpa laporan akhir.

## Temuan soal cadangan

Snapshot JORC berbeda tanggal dan assumptions: sekitar 764 juta ton per 2018, sekitar 1.150 juta ton per 2019, dan 2.031 juta ton per 1 April 2022. Lompatan tidak sama dengan eksplorasi atau akuisisi cadangan saja: revisi rencana tambang, ekonomi, harga, izin dan cakupan entitas dapat mengubah estimasi. Situs Bayan saat penelitian ini tetap menampilkan basis JORC 2022; jangan mengklaim 2.031 juta ton sebagai cadangan aktual Oktober 2026.

## Anomali data yang harus diinvestigasi

1. **Perubahan hasil FY2012**: laporan keuangan 2012 menunjukkan laba setahun US$54,946917 juta; tabel komparatif FY2012* dalam Annual Report 2013 menyajikan rugi US$13,748426 juta. Penjelasan *restated* tercantum pada laporan 2013; perlu membaca catatan perubahan kebijakan akuntansi/konsolidasi untuk memastikan sebab dan memilih seri laba yang konsisten.
2. **Volume 2016**: laporan FY2016 versi mirror menunjukkan produksi 9,7 juta ton, sedangkan presentasi investor resmi 2019 merangkum 9,8 juta ton. Selisih sekitar 0,1 juta ton diperlakukan sebagai ambiguitas definisi/pembulatan.
3. **Pendapatan 2010**: angka komparatif dalam tabel FY2012 menunjukkan US$962,386640 juta, sedangkan sumber agregator sekitar US$959,394953 juta. Dua angka dipertahankan di catatan; versi laporan resmi digunakan dalam panel sementara.
4. **Rata-rata harga jual 2025**: dalam penjelasan perusahaan muncul angka sekitar US$48,1 dan US$48,4 per ton untuk konteks berbeda. Panel memakai 48,4 (tinjauan manajemen) dan harus diselaraskan bila membandingkan dengan pendapatan batu bara.
5. **Perbedaan laba FY2025**: US$784,051 juta laba tahun berjalan mencakup kepentingan nonpengendali; untuk penghitungan akumulasi laba pemegang saham induk gunakan US$767,916 juta.

## Hal yang TIDAK bisa disimpulkan dari dataset ini

- Seluruh US$31,696 miliar pendapatan adalah kekayaan Low Tuck Kwong.
- Seluruh batu bara atau laba Bayan mengalir ke Singapura.
- Seluruh produksi berasal dari Tabang / Kutai Kartanegara (Bayan juga beroperasi di kabupaten lain dan di Kalimantan Selatan).
- Semua pendapatan adalah nilai tambah nasional, atau jumlah yang tersedia untuk belanja sekolah.
- 2,031 miliar ton cadangan per Apr 2022 adalah cadangan terukur pada Okt 2026.

## Materi visual yang aman untuk korsel

1. Slide grafik tonase 2015–2025: ~11,3 juta ton meningkat menjadi 68 juta ton; sertakan 384 juta ton total indikator.
2. Slide grafik revenue 2015–2025: puncak revenue US$4,70 miliar pada 2022, meski produksi tertinggi pada 2025.
3. Slide satu tahun 2025: US$3,43 miliar pendapatan; US$784 juta laba konsolidasi; US$700 juta dividen; US$263 juta royalti kas dan US$321 juta PPh kas dibayarkan. Cantumkan penjelasan bahwa pos berbeda dasar.
4. Slide integrasi berikutnya menghubungkan hak dividen dengan pemilik pada *recording date*, bukan menyamakan US$700 juta dengan dana asing.

## Sumber utama terpilih

- Annual Report 2025 Bayan: https://www.bayan.com.sg/cfind/source/files/annual-report/ar-bayan-2025-website-070526.pdf
- Investor Presentation Maret 2019 Bayan: https://www.bayan.com.sg/cfind/source/files/investor/investor-update/bayan%20group%20march%202019%20-%2024%20april%202019.pdf
- Annual Report 2020 Bayan: https://www.bayan.com.sg/cfind/source/files/ar2020-bayan-fullset-for-web_31may-final.pdf
- Annual Report 2022 Bayan: https://www.bayan.com.sg/cfind/source/files/ar-2022-byan-final.pdf
- Audited financial statements 2012 Bayan: https://www.bayan.com.sg/cfind/source/files/financial-report/financial-report-ind/tahunan/Consolidated%20Financial%20Statements%202012%20%28Audited%29.pdf
- Annual Report 2013 (mirror dokumen): https://cdn.indonesia-investments.com/bedrijfsprofiel/2399/bayan-resources-annual-report-2013-byan-company-profile-indonesia-investments.pdf
- Reserves JORC Bayan: https://www.bayan.com.sg/sumber-daya-dan-cadangan

Daftar lengkap 19 sumber, tautan, kategori, dan bukti tiap angka ada pada `bayan_source_registry.csv` dan `bayan_evidence_ledger.csv`.
