# Panduan pemulihan

1. Ekstrak ZIP ke direktori kerja baru.
2. Buka `metadata_backup/DAFTAR_TAHAP.csv` untuk melihat status sumber per tahap.
3. Pertahankan jalur folder `dataset_tahap/value_capture_stage*` ketika menggabungkan data.
4. Jangan menimpa hasil parsial dengan angka nol. Sel kosong berarti data belum didapat atau belum terverifikasi.
5. File `.zip` yang tersimpan di `arsip_asli/` mempertahankan paket original, termasuk skrip dan konfigurasi yang tidak ada di folder stage.
6. Jalankan verifikasi SHA256 pada manifest sebelum melakukan transformasi atau perhitungan lanjutan.

Contoh verifikasi (Python):

```python
import csv, hashlib
from pathlib import Path
root=Path('.')
with (root/'metadata_backup/MANIFEST_SHA256.csv').open(encoding='utf-8-sig', newline='') as f:
    for row in csv.DictReader(f):
        p=root/row['path_dalam_backup']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'], p
print('Semua checksum cocok')
```
