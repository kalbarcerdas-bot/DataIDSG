# Handoff riset untuk melanjutkan di percakapan baru

## Tujuan penelitian
Mengukur annual economic value capture terkait hubungan Indonesia-Singapura 2003-2025 dengan pembedaan ketat antara transaksi bruto, stok investasi, nilai tambah domestik, pendapatan investasi, dan manfaat ekonomi yang jatuh pada pemilik akhir. Hasil akhir diarahkan ke website HTML, tetapi pengguna meminta seluruh tahap persiapan disimpan sebagai CSV; jangan membuat HTML baru sampai fase publikasi.

## Pola kerja
Riset dan analisis utama di ChatGPT, menggunakan data resmi publik dan laporan tahunan. Hermes + Scrapling hanya digunakan apabila diperlukan scraping skala besar yang tidak tersedia melalui API/unduhan resmi. Database dibuat dapat ditelusuri sampai URL sumber, tahun dan metodologi.

## Tahapan yang sudah dikerjakan
- Tahap 1: perdagangan barang bilateral 2003-2025 dari BPS, plus pembanding mirror Singapura yang belum sepenuhnya terverifikasi.
- Tahap 2: stok dan komposisi investasi langsung Singapura di Indonesia dari SingStat (seri mulai 1994).
- Tahap 2B: porsi Indonesia pada stok investasi luar negeri Singapura dan matriks data pendapatan/sektor yang belum lengkap.
- Tahap 3: perdagangan jasa bilateral 2003-2024 dari SingStat, 2025 masih kosong.
- Tahap 3B: kategori jasa 12 jenis, rancangan API/CSV; angka bilateral kategori belum lengkap.
- Tahap 4: pembayaran pendapatan investasi langsung oleh Indonesia kepada investor asing agregat seluruh negara untuk 2015-2025; angka khusus investor Singapura belum diperoleh.
- Tahap 5: observasi komoditas awal untuk sawit, batu bara, petroleum dan nikel, serta matrix gap historis.
- Tahap 6: sampel enam grup perusahaan dengan laporan keuangan, termasuk rekonsiliasi laba bisnis Indonesia menurut laporan JC&C.
- Tahap 7: jaringan entitas/kepemilikan dan penilaian pemilik akhir enam grup; hak ekonomi final belum dapat dipetakan sepenuhnya.
- Tahap 8: indikator OECD TiVA/ICIO serta struktur data 2003-2025; seri numerik bilateral OECD belum berhasil diambil lengkap.

## Prioritas tindak lanjut
1. Isi nilai bilateral OECD TiVA melalui unduhan CSV/API resmi untuk indikator target.
2. Tarik dataset kategori jasa SingStat resmi dan rekonsiliasi total dengan Tahap 3.
3. Cari pendapatan investasi FDI bilateral Indonesia-Singapura untuk memisahkan laba Singapura dari seluruh investor asing.
4. Lengkapi historis komoditas dan verifikasi arah barang versus merchanting/trading.
5. Perkuat bukti arus dividen, laba ditahan, bunga, beneficial ownership dari laporan perusahaan; jangan memakai laba grup sebagai laba yang diterima resident Singapura.
6. Sebelum membangun website, buat seri angka validated dengan satuan konsisten, mata uang asli + kurs dan audit double counting.

## Konvensi ilmiah
- Tidak mengubah `missing` menjadi nol.
- Seluruh estimasi wajib memisahkan measured versus modeled.
- Jangan menjumlahkan nilai transaksi, surplus perdagangan, stok FDI, dan laba konsolidasi sebagai total value capture.
- Tahun dan definisi pada seri berbeda harus dipertahankan dan ditandai bila data sementara/direvisi.
- Tabel dan sumber dalam ZIP adalah hasil progres dan **bukan verifikasi lengkap ulang dari setiap angka**.

## Struktur penting dalam arsip ini
`dataset_tahap/value_capture_stage*` = file penelitian yang sudah dibuat.
`arsip_asli/*.zip` = arsip historis lengkap, termasuk file tambahan yang mungkin tidak tersedia di folder penelitian.
`metadata_backup/MANIFEST_SHA256.csv` = nilai hash SHA-256 setiap file sumber; periksa integritas setelah ekstraksi.
