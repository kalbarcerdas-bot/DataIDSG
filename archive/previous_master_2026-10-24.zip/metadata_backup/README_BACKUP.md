# Backup penelitian Value Capture Indonesia–Singapura

**Tanggal pengarsipan:** 24 Oktober 2026  
**Ruang lingkup:** Blueprint + Tahap 1, 2, 2B, 3, 3B, 4, 5, 6, 7, dan 8.  
**Format utama:** CSV; JSON, markdown, skrip Python, dan HTML lama disertakan bila sudah pernah dibuat.

## Cara membaca

- Folder `dataset_tahap/`: salinan file yang sudah tersedia dari tiap tahap penelitian.
- Folder `arsip_asli/`: ZIP tahap sebelumnya, disimpan apa adanya agar skrip/metadata tambahan yang hanya ada di arsip lama tidak hilang.
- Folder `metadata_backup/`: manifest integritas SHA-256 dan ringkasan cakupan pekerjaan.

**Catatan sangat penting:** Arsip ini merupakan backup progres penelitian, **bukan database akhir terverifikasi secara penuh**. Angka perdagangan bruto, FDI stock, income semua negara, dan laba konsolidasi perusahaan tidak boleh dijumlahkan sebagai value capture Singapura. Beberapa tahap berisi nilai kosong, angka sementara, dan entri belum terverifikasi; baca README, source registry, validation, coverage, dan data gaps masing-masing tahap sebelum memakainya untuk publikasi.

Tidak ada halaman website baru dibuat dalam proses backup ini. File HTML yang ada hanyalah salinan prototipe dari tahap sebelumnya.

## Pemeriksaan integritas

Gunakan `metadata_backup/MANIFEST_SHA256.csv` untuk membandingkan SHA256 dan ukuran setiap file sumber setelah ekstraksi. Backup ZIP ini juga telah diuji integritas CRC.
