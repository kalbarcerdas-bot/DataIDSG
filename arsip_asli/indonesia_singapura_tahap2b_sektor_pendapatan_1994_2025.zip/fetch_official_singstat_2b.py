#!/usr/bin/env python3
"""Unduh data PUBLIC SingStat 2B via API resmi data.gov.sg. No accounts needed.
Run in Hermes/laptop with internet and requests installed: python fetch_official_singstat_2b.py
Does NOT infer sector, does NOT scrape protected pages, preserves raw JSON/CSV metadata.
"""
import requests, csv, json, hashlib, time
from pathlib import Path
BASE='https://data.gov.sg/api/action/datastore_search'
SOURCES={'M081971':'d_dea084e8924680c954f1569a27f6d96c',
         'M082051':'d_3dcfd9108ee04bd2b7978d6eaab1ed9a'}
DIR=Path('incoming/raw_singstat_2b');DIR.mkdir(parents=True,exist_ok=True)
S=requests.Session();S.headers.update({'User-Agent':'PublicAcademicResearch/1.0 contact-via-dataset-portal'})
def get_all(resource_id):
    all_rows=[];offset=0;batch=100
    for page in range(20):
        r=S.get(BASE,params={'resource_id':resource_id,'limit':batch,'offset':offset},timeout=40)
        r.raise_for_status();payload=r.json()
        result=payload.get('result',{})
        if payload.get('success') is False: raise RuntimeError(str(payload)[:400])
        data=result.get('records')
        if data is None: raise RuntimeError('Unrecognized API schema; inspect raw response, do not guess.')
        if not isinstance(data,list):raise TypeError('records not a list')
        all_rows.extend(data);offset+=len(data)
        total=result.get('total')
        print('resource',resource_id,'rows',offset,'declared total',total)
        if not data or len(data)<batch or (isinstance(total,int) and offset>=total):break
        time.sleep(0.6)
    return all_rows
for code,rid in SOURCES.items():
    data=get_all(rid)
    if len(data)<250: raise RuntimeError(f'{code}: got {len(data)} rows, expected roughly 330. Do not publish partial dataset')
    payload=json.dumps({'resource_id':rid,'retrieval_url':BASE,'rows':data},ensure_ascii=False,indent=2).encode('utf-8')
    path=DIR/(code+'_original_records.json');path.write_bytes(payload)
    columns=list(dict.fromkeys(k for r in data for k in r))
    csv_path=DIR/(code+'_all_records.csv')
    with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(data)
    (DIR/(code+'_audit.json')).write_text(json.dumps({'source':rid,'row_count':len(data),'sha256':hashlib.sha256(payload).hexdigest(),'columns':columns,'indonesia_candidates':[r for r in data if 'indonesia' in str(r.get('DataSeries','')).lower()]},indent=2,ensure_ascii=False),encoding='utf-8')
    print(code,len(data),'saved',path)
print('DONE: Return incoming/raw_singstat_2b folder to ChatGPT for verification; do not draw sector conclusions here.')
