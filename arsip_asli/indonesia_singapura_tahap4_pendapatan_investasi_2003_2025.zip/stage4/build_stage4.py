import csv,json,os,zipfile,html,datetime,hashlib
from pathlib import Path
BASE=Path('/mnt/data/value_capture_stage4'); BASE.mkdir(parents=True,exist_ok=True)
STOCKFILE=Path('/mnt/data/value_capture_stage2/singapore_fdi_indonesia_1994_2025.csv')
stock={}
with STOCKFILE.open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  stock[int(r['year'])]=float(r['singstat_dia_stock_sgd_million']) if r['singstat_dia_stock_sgd_million'] else None
SOURCES={
 'BI_2016':{'title':'Laporan NPI Triwulan IV 2016','url':'https://www.bi.go.id/id/publikasi/laporan/Documents/Laporan-NPI-Tw%20-IV-2016-260417.pdf','page_printed':34,'pdf_page':40,'table':'Tabel 4 Pendapatan Primer','vintage':'Februari 2017','years':[2015,2016]},
 'BI_2019':{'title':'Laporan NPI Triwulan IV 2019','url':'https://www.bi.go.id/id/publikasi/laporan/Documents/NPI_Tw.IV-2019.pdf','page_printed':36,'pdf_page':42,'table':'Tabel 4 Pendapatan Primer','vintage':'Februari 2020','years':[2017,2018,2019]},
 'BI_2022':{'title':'Laporan NPI Triwulan IV 2022','url':'https://www.bi.go.id/id/publikasi/laporan/Documents/NPI-Tw.IV_2022.pdf','page_printed':36,'pdf_page':42,'table':'Tabel 4 Pendapatan Primer','vintage':'Februari 2023','years':[2020,2021]},
 'BI_2024':{'title':'Laporan NPI Triwulan IV 2024','url':'https://www.bi.go.id/id/publikasi/laporan/Documents/NPI_Tw-IV_2024.pdf','page_printed':34,'pdf_page':40,'table':'Tabel 4 Pendapatan Primer','vintage':'Februari 2025','years':[2022]},
 'BI_2026':{'title':'Laporan NPI Triwulan I 2026','url':'https://www.bi.go.id/id/publikasi/laporan/Documents/NPI_Tw-I_2026.pdf','page_printed':30,'pdf_page':36,'table':'Tabel 4 Pendapatan Primer','vintage':'Mei 2026','years':[2023,2024,2025]},
 'SINGSTAT':{'title':'Singapore Direct Investment Abroad by Destination','url':'https://data.gov.sg/datasets/d_a1db0947cc69ae27d0ffb6ddfaf6cdde/view','table':'M084431','vintage':'2026','years':list(range(2003,2025))}
}
# All values reported by Bank Indonesia in USD million, as positive magnitudes for "Pembayaran".
# payment on equity | payment on direct debt (interest) | receipts equity | receipts interest | original negative direct investment income balance | source ID
OBS={
 2015:(17153,1440,72,16,-18504,'BI_2016'),
 2016:(16687,1101,90,73,-17625,'BI_2016'),
 2017:(20815,971,1999,14,-19773,'BI_2019'),
 2018:(21316,1176,4909,43,-17541,'BI_2019'),
 2019:(20841,849,3351,60,-18280,'BI_2019'),
 2020:(16219,656,2114,24,-14737,'BI_2022'),
 2021:(20543,522,3009,32,-18024,'BI_2022'),
 2022:(24458,536,2977,23,-21993,'BI_2024'),
 2023:(24066,614,2767,138,-21775,'BI_2026'),
 2024:(24327,727,3079,111,-21863,'BI_2026'),
 2025:(25114,584,2555,105,-23039,'BI_2026'),
}
rows=[]
for year in range(2003,2026):
 v=OBS.get(year)
 eq,interest,rec_eq,rec_int,balance,sid = v if v else (None,None,None,None,None,None)
 if v:
  total=eq+interest
  receipts=rec_eq+rec_int
  residual=balance -(receipts-total)
  assert abs(residual)<=1, (year,residual)
 else:
  total=receipts=residual=None
 rows.append({'year':year,'reporter':'Indonesia','counterparty_scope':'ALL FOREIGN INVESTORS (NOT SPECIFIC TO SINGAPORE)',
  'id_fdi_equity_income_payments_usd_million':eq,'id_fdi_intercompany_interest_payments_usd_million':interest,
  'id_fdi_total_income_payments_usd_million':total,'id_fdi_equity_income_receipts_usd_million':rec_eq,
  'id_fdi_intercompany_interest_receipts_usd_million':rec_int,'id_fdi_total_income_receipts_usd_million':receipts,
  'id_fdi_income_balance_usd_million_reported':balance,
  'id_fdi_income_balance_reconciliation_residual_usd_million':residual,
  'sg_bilateral_fdi_income_from_indonesia_usd_million':None,
  'sg_bilateral_cash_dividends_from_indonesia_usd_million':None,
  'sg_bilateral_reinvested_earnings_from_indonesia_usd_million':None,
  'sg_bilateral_intercompany_interest_from_indonesia_usd_million':None,
  'sg_fdi_stock_indonesia_sgd_million_CONTEXT_NOT_INCOME':stock.get(year),
  'bi_data_status':('not_extracted_for_year' if not v else ('provisional' if year==2025 else ('revised_publication' if year in (2017,2018,2020,2021,2022,2023) else 'published'))),
  'singapore_attribution_status':'NOT_AVAILABLE_DO_NOT_ESTIMATE',
  'source_id':sid,'source_url':SOURCES[sid]['url'] if sid else None,
  'source_pdf_page':SOURCES[sid]['pdf_page'] if sid else None,
  'publication_vintage':SOURCES[sid]['vintage'] if sid else None,
  'metric_note':'Current-account investment income payments incl. reinvested earnings; NOT cash remittance, NOT Singapore bilateral amount. SGD stock distinct from USD annual income.'})
fields=list(rows[0]); csvpath=BASE/'stage4_fdi_income_2003_2025.csv'
with csvpath.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
jsonpath=BASE/'stage4_fdi_income_2003_2025.json';jsonpath.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
source_rows=[]
for k,s in SOURCES.items(): source_rows.append({'source_id':k,**s,'pages_1_based':s.get('pdf_page'),'scope':('Singapore-origin outward FDI stock, not income' if k=='SINGSTAT' else 'Indonesia all nonresident economies, not Singapore bilateral')})
(BASE/'source_registry.json').write_text(json.dumps(source_rows,ensure_ascii=False,indent=2),encoding='utf-8')
with (BASE/'stage4_source_registry.csv').open('w',encoding='utf-8-sig',newline='') as f:
 cols=['source_id','title','url','page_printed','pdf_page','table','vintage','scope','years'];w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows([{**d,'years':','.join(str(a) for a in d['years'])} for d in source_rows])
# A full status matrix for analytical measures with explicit missing-value handling.
measures=['bilateral_fdi_income_total','bilateral_cash_dividends','bilateral_reinvested_earnings','bilateral_intercompany_interest','ultimate_sg_beneficiary_income']
with (BASE/'stage4_bilateral_missingness_2003_2025.csv').open('w',encoding='utf-8-sig',newline='') as f:
 cols=['year','metric','value_usd_million','status','reason','next_best_source'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for yr in range(2003,2026):
  for m in measures: w.writerow({'year':yr,'metric':m,'value_usd_million':'','status':'not_verified_public_bilateral','reason':'BI table is all countries. No disaggregated bilateral income in verified SingStat official outward-stock series.','next_best_source':'Corporate filings / bilateral inward FDI-income data request / OECD BMD4 source data review'})
# Quality check / manifest
validation={'years':23,'global_income_years_present':sum(bool(r['source_id']) for r in rows), 'bilateral_sg_income_years_present':0,'range_observed':'2015–2025','unit_usd':'USD millions','min_max_income_debit':[min(x[0]+x[1] for x in OBS.values()),max(x[0]+x[1] for x in OBS.values())],'max_reconciliation_residual_usd_million':max(abs(r['id_fdi_income_balance_reconciliation_residual_usd_million']) for r in rows if r['source_id']), 'all_balance_valid_within_rounding':True,'singapore_bilateral_not_imputed':all(r['sg_bilateral_fdi_income_from_indonesia_usd_million'] is None for r in rows)}
(BASE/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
report=f'''# TAHAP 4 — Investment Income Accounting / Pendapatan Investasi Indonesia–Singapura

Tanggal kajian: 24 Oktober 2026. Penelitian menggunakan sumber publik, tanpa akun berbayar.

## HASIL YANG TELAH DIAMBIL

- **11 tahun (2015–2025)** angka resmi **pembayaran pendapatan investasi langsung Indonesia kepada seluruh investor asing** (juta USD), diuraikan menjadi pendapatan ekuitas serta bunga instrumen utang antarpihak terkait.
- **23 baris (2003–2025)** dalam dataset panel; 2003–2014 masih kosong untuk agregat global agar tidak mengarang angka. Ini BUKAN indikasi nilainya nol.
- **23 tahun data khusus Singapura untuk pendapatan investasi tetap kosong**, karena seri bilateral yang cocok belum berhasil ditemukan/ diverifikasi dalam sumber publik yang sudah dicek.
- Seri **stok FDI Singapura ke Indonesia (SGD)** disertakan sebagai konteks terpisah dari Tahap 2; angka stok bukan laba dan tidak dijumlahkan dengan arus pendapatan (USD).

## TEMUAN TERPILIH (SELURUH NEGARA INVESTOR, BUKAN SINGAPURA)

| Tahun | Ekuitas (juta USD) | Bunga (juta USD) | Total pembayaran (juta USD) | Sumber |
|---|---:|---:|---:|---|
'''
for yr in sorted(OBS):
 eq,it,*_,sid=OBS[yr]; report+=f'| {yr} | {eq:,} | {it:,} | {eq+it:,} | {sid} |\n'
report+='''
## KAIDAH INTERPRETASI

1. 'Pembayaran' pada akun pendapatan investasi neraca pembayaran **tidak otomatis berarti transfer kas**; mencakup laba ditahan yang dicatat sebagai pendapatan terutang dan reinvestasi.
2. 'Pendapatan modal ekuitas' BI adalah kategori **laba investasi atas ekuitas**, BUKAN angka dividen tunai yang terisolasi. Jangan diberi label dividen.
3. 'Pendapatan utang (bunga)' adalah komponen yang berbeda dengan jasa keuangan (Tahap 3) dan berbeda dengan pinjaman pokok yang masuk akun finansial.
4. Total kepada semua investor asing tidak boleh dianggap sebagai pendapatan investor Singapura atau dikalikan proporsi stok investasi Singapura tanpa model dengan asumsi dan rentang ketidakpastian.
5. Persentase yield = income/global stock SG *tidak valid* bila pembilang seluruh investor asing, bukan Singapura. Perubahan stok bukan net investment income.
6. Sumber publik beberapa tahun memiliki status sementara atau telah direvisi; `publication_vintage` disimpan sehingga pembacaan historis transparan.
7. Rounding sekitar US$1 juta diperbolehkan pada rekonsiliasi income credit - debit = saldo.

## SUMBER (HALAMAN PDF)
'''
for sid,s in SOURCES.items():
 report+=f'- **{sid}:** {s["title"]}; {s["url"]}'+(f' ; halaman tercetak {s["page_printed"]}, halaman PDF {s["pdf_page"]}' if 'page_printed' in s else '')+'\n'
report+='''
## PEMERIKSAAN DATA BILATERAL

- SingStat outward FDI menurut negara tujuan tersedia sebagai **stok**, bukan pendapatan keuntungan tiap negara.
- SingStat *Income of Foreign Direct Investment in Singapore by Source Economy* memiliki arah terbalik: pendapatan atas investasi asing di Singapura, sehingga DILARANG dipakai sebagai pendapatan Singapura dari Indonesia.
- ASEANstats FDI flows by source/destination mengukur **modal investasi**, bukan pendapatan investasi yang berasal dari modal tersebut.
- Statistik pendapatan investasi yang dipublikasi BI menguraikan agregat semua negara; tidak ada pemisahan bilateral pada Tabel 4 yang diverifikasi.
- OECD 'FDI income receipts by partner country' adalah definisi indikator yang sesuai, tetapi tabel indikator publiknya memiliki cakupan terbatas. Belum ditemukan angka SG-ID yang dapat diekstraksi langsung; ini menjadi *research lead*, bukan observasi.

## KELANJUTAN RISET

A. Periksa apakah terdapat tabel OECD/BMD4 untuk pasangan Singapura–Indonesia dengan tahun terukur; simpan definisi immediate investor.
B. Telusuri laporan tahunan anak perusahaan Indonesia dan holding Singapura; simpan laba setelah pajak, laba ditahan, dividen diumumkan/dibayar, bunga pihak berelasi, kepemilikan, dan catatan pajak menurut tahun.
C. Pisahkan *cash dividend* dari reinvested earnings dan pastikan hubungan parent-subsidiary, negara tempat usaha, dan ultimate beneficiary.
D. Jika ekstraksi 100+ PDF diperlukan, sediakan tugas Hermes+Scrapling hanya untuk unduh halaman terbuka dan dokumen laporan resmi (taati ketentuan akses situs, tanpa bypass).

**Catatan akhir:** Belum ada nilai pendapatan investasi Singapura dari Indonesia yang bisa diterbitkan sebagai 'value capture' tahunan spesifik Singapura pada Tahap 4 ini.
'''
(BASE/'RESEARCH_REPORT.md').write_text(report,encoding='utf-8')
# Hermes task is optional, meant for a future concrete batch, not a scraping demand now.
hermes='''# HERMES TASK — JANGAN JALANKAN SEBELUM TARGET PERUSAHAAN DISETUJUI

Tujuan: gunakan hanya untuk pengumpulan massal laporan tahunan / laporan keuangan publik jika manual tidak efisien. Jangan scraping BI/SingStat bila tabel resmi dapat diunduh dari API atau halaman resminya.

1. Input: daftar URL perusahaan, daftar situs laporan tahunan resmi, periode 2003–2025.
2. Unduh laporan resmi sesuai Terms of Service, robots.txt, rate limit, tanpa melewati login/CAPTCHA/pembatasan akses.
3. Hasil `downloads_manifest.csv`: issuer, legal_entity_name, report_year, document_type, source_url, download_date, local_path, sha256, page_count, extraction_status.
4. Hasil `corporate_income_events.csv`: subsidiary, parent, ownership_pct, accounting_period, transaction_type (declared_dividend/paid_dividend/reinvested_earnings/intercompany_interest/profit), value, currency, original_text, PDF_page, source_document_id, confidence_flag.
5. Jangan menghitung tahun tanpa disclosure; data hilang = kosong. Jangan mengasumsikan laba konsolidasi sepenuhnya dari Indonesia.
6. Semua extraction harus menyimpan kutipan 1–2 kalimat kontekstual dan halaman sumber untuk pemeriksaan manusia.
7. Output CSV/JSON dan arsip file sumber. Import ke ChatGPT untuk validasi dan atribusi akhir.
'''
(BASE/'HERMES_OPTIONAL_TASK.md').write_text(hermes,encoding='utf-8')
# Offline HTML UI (self-contained). Embed data, no CDN dependencies.
data_json=json.dumps(rows,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
htmltext=r'''<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stage 4 • Indonesia–Singapore Value Capture</title><style>
:root{--bg:#f5f7f6;--card:#fff;--ink:#13283c;--sub:#536779;--teal:#1b8990;--navy:#101d2a;--amber:#d7a052;--line:#dce5e4}*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;background:var(--bg);color:var(--ink)}.container{max-width:1110px;margin:auto;padding:36px 24px 80px}header{border-bottom:1px solid var(--line);padding-bottom:25px;display:flex;justify-content:space-between;gap:18px;align-items:start}header small,.eyebrow{letter-spacing:1.7px;text-transform:uppercase;color:var(--teal);font-size:11px;font-weight:800}h1{font-size:clamp(28px,3.5vw,44px);letter-spacing:-1.1px;line-height:1.1;margin:12px 0}p{color:var(--sub);line-height:1.6;margin:10px 0}.stamp{background:var(--navy);color:white;border-radius:8px;padding:10px 12px;font-size:12px;white-space:nowrap}.notice{border-left:4px solid var(--amber);background:#fffdf8;padding:15px 17px;margin:24px 0;border-radius:0 9px 9px 0;color:#5e512d}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:20px;min-width:0}.metric-label{font-size:12px;color:var(--sub)}.metric-value{font-size:clamp(26px,3vw,36px);letter-spacing:-1.1px;font-weight:750;margin:10px 0}.metric-foot{font-size:12px;color:var(--sub)}.muted{color:var(--sub)}.section{margin-top:25px}h2{font-size:18px;margin:0 0 8px}h3{font-size:14px}.bar{height:14px;background:var(--line);border-radius:99px;display:flex;overflow:hidden;margin:14px 0 8px}.bar>div:first-child{background:var(--teal)}.bar>div:last-child{background:var(--amber)}.legend{display:flex;gap:17px;flex-wrap:wrap;font-size:12px;color:var(--sub)}.dot{display:inline-block;border-radius:100%;height:9px;width:9px;margin-right:5px}.controls{display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap}.controls select{border:1px solid #bdcfcb;background:white;padding:9px 11px;border-radius:8px;font:inherit;color:var(--ink)}.series{display:flex;gap:5px;align-items:flex-end;height:230px;padding:18px 0 0;border-bottom:1px solid var(--line)}.series .yearbar{flex:1;height:100%;display:flex;flex-direction:column;justify-content:end;align-items:center;cursor:pointer;min-width:0;position:relative}.colbar{width:min(80%,41px);background:var(--teal);border-radius:5px 5px 0 0;transition:background .15s}.yearbar.active .colbar{background:var(--navy)}.yearbar .tick{font-size:10px;margin-top:7px;color:var(--sub);position:absolute;bottom:-22px}.yearbar[aria-disabled="true"]{cursor:default}.yearbar[aria-disabled="true"] .colbar{background:var(--line)}.yearbar:hover .colbar{filter:brightness(.9)}.data-table{border-collapse:collapse;width:100%;margin-top:9px;font-size:13px}.data-table th,.data-table td{padding:10px;border-bottom:1px solid var(--line);text-align:right}.data-table th:first-child,.data-table td:first-child{text-align:left}.data-table th{font-size:11px;letter-spacing:.4px;text-transform:uppercase;color:var(--sub)}.data-table tr:hover{background:#f6faf9}a{color:var(--teal)}.source{font-size:11px}.tag{display:inline-block;background:#e6f3f1;border:1px solid #c8e7e2;border-radius:6px;font-size:11px;padding:3px 6px;color:#0f6369}.tag.warn{background:#fff5de;border-color:#f1dfa8;color:#795a12}.twocol{display:grid;grid-template-columns:1.25fr 1fr;gap:15px}@media(max-width:750px){.grid,.twocol{grid-template-columns:1fr}header{display:block}.stamp{display:inline-block} .container{padding:22px 15px 50px}.data-table{font-size:11px}.data-table th,.data-table td{padding:7px 4px}.series{gap:2px}}.numm{font-variant-numeric:tabular-nums}
</style></head><body><div class="container"><header><div><small>Value Capture Observatory / Research Stage 04</small><h1>Pendapatan Investasi<br>Indonesia → Investor Asing</h1><p>Analisis historis 2003–2025 • Sumber Bank Indonesia • Bahasa Indonesia</p></div><span class="stamp">RESEARCH DATA · 24 OKT 2026</span></header><div class="notice"><strong>Batas interpretasi:</strong> seluruh nilai pendapatan dalam dashboard ini adalah <strong>pembayaran Indonesia kepada semua negara investor</strong>, bukan jumlah yang diterima Singapura. Pendapatan khusus Singapura belum terverifikasi dan selalu ditampilkan sebagai <em>data belum tersedia</em>.</div><section class="section"><div class="controls"><h2>Ringkasan tahun terpilih</h2><label for="year">Pilih tahun &nbsp;<select id="year" aria-label="Pilih tahun"></select></label></div><div class="grid"><div class="card"><div class="metric-label">Pendapatan investasi langsung yang dibayarkan • seluruh negara</div><div class="metric-value numm" id="total">—</div><div class="metric-foot" id="totalnote">USD miliar / tahunan</div></div><div class="card"><div class="metric-label">Komponen ekuitas • seluruh negara</div><div class="metric-value numm" id="equity">—</div><div class="metric-foot">Termasuk laba yang diinvestasikan kembali</div></div><div class="card"><div class="metric-label">Komponen bunga antarperusahaan • seluruh negara</div><div class="metric-value numm" id="interest">—</div><div class="metric-foot">Bagian dari pendapatan investasi langsung</div></div></div></section><section class="section twocol"><div class="card"><h2>Komposisi pembayaran</h2><p>Proporsi tahunan pendapatan ekuitas dan bunga dari total pembayaran kepada seluruh investor asing.</p><div class="bar"><div id="eqbar" style="width:0"></div><div id="itbar" style="width:0"></div></div><div class="legend"><span><i class="dot" style="background:var(--teal)"></i>Ekuitas <strong id="eqpct">—</strong></span><span><i class="dot" style="background:var(--amber)"></i>Bunga <strong id="itpct">—</strong></span></div><p class="source" id="source">Sumber per tahun: —</p></div><div class="card"><h2>Berapa yang diterima Singapura?</h2><div class="metric-value" style="font-size:28px">Belum terverifikasi</div><p>Seri pendapatan FDI bilateral Singapura dari Indonesia belum ditemukan dengan cakupan dan definisi yang cocok. Nilai dalam panel kiri <strong>tidak boleh dipakai</strong> sebagai estimasi penerimaan Singapura.</p><span class="tag warn">MISSING — not zero</span></div></section><section class="section card"><h2>Tren pembayaran tahunan kepada seluruh investor asing</h2><p>USD miliar (nominal). Tahun 2003–2014 belum diekstraksi pada tahap ini; tidak dianggap nol.</p><div class="series" id="bars" role="img" aria-label="Grafik tahunan pendapatan FDI semua negara"></div><div style="height:32px"></div><div class="legend"><span><i class="dot" style="background:var(--teal)"></i>Data resmi historis</span><span><i class="dot" style="background:var(--navy)"></i>Tahun terpilih</span><span><i class="dot" style="background:var(--line)"></i>Belum diekstraksi</span></div></section><section class="section card"><h2>Pembanding terpisah: stok investasi Singapura di Indonesia</h2><p>Nilai stok pada akhir tahun dari SingStat (juta SGD), <strong>bukan</strong> pendapatan investasi tahunan. Perbedaan valuta dan jenis indikator tidak boleh digabung dalam perhitungan satu metrik.</p><div class="metric-value" id="stock">—</div><div class="metric-foot">Sumber: <a href="https://data.gov.sg/datasets/d_a1db0947cc69ae27d0ffb6ddfaf6cdde/view" target="_blank" rel="noopener">SingStat M084431</a>.</div></section><section class="section card"><h2>Tabel data audit • 2015–2025</h2><p>US$ miliar • Komponen ekuitas dan bunga dijumlahkan untuk memperoleh total. Selisih terhadap nilai neraca pembayaran bisa ±US$1 juta karena pembulatan BI.</p><div style="overflow:auto"><table class="data-table"><thead><tr><th>Tahun</th><th>Pendapatan ekuitas</th><th>Bunga</th><th>Total dibayarkan</th><th>Status</th><th>Sumber</th></tr></thead><tbody id="table"></tbody></table></div></section><section class="section card"><h2>Metodologi dan audit trail</h2><p><strong>Angka pembayaran</strong> berasal dari Tabel 4, akun pendapatan investasi langsung, lalu dicatat sebagai besar pembayaran positif. Seri bilateral investor Singapura tetap kosong. Transaksi penghasilan atas ekuitas dalam neraca pembayaran tidak sama dengan kas dividen. Setiap angka pada tabel mempunyai tautan menuju laporan asli. Angka lama bisa direvisi oleh BI sehingga <em>vintage</em> publikasi disimpan.</p><p><a href="https://www.bi.go.id/id/statistik/ekonomi-keuangan/seki/default.aspx" target="_blank" rel="noopener">BI SEKI</a> · <a href="https://data.gov.sg/datasets/d_a1db0947cc69ae27d0ffb6ddfaf6cdde/view" target="_blank" rel="noopener">SingStat FDI stock</a> · <a href="https://www.oecd.org/en/data/indicators/fdi-income-receipts-by-partner-country.html" target="_blank" rel="noopener">OECD — income receipts by partner</a></p><p class="source">Disiapkan untuk digabungkan dengan website penelitian akhir. Semua data tersedia dalam JSON dan CSV terpisah di paket tahap 4.</p></section></div><script>const DATA=__EMBEDDED_DATA__;const $=id=>document.getElementById(id);const opt=$('year');const dataByYear=Object.fromEntries(DATA.map(r=>[r.year,r]));const currency=v=>v==null?'Data belum tersedia':`US$${(v/1000).toLocaleString('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2})} miliar`;const labels={not_extracted_for_year:'Belum diekstraksi',provisional:'Sementara',revised_publication:'Publikasi revisi',published:'Terbit'};function renderYear(yr){const d=dataByYear[yr];opt.value=yr;$('total').textContent=currency(d.id_fdi_total_income_payments_usd_million);$('equity').textContent=currency(d.id_fdi_equity_income_payments_usd_million);$('interest').textContent=currency(d.id_fdi_intercompany_interest_payments_usd_million);$('totalnote').textContent=(d.source_id?'Tahun '+yr+' · sumber: '+d.source_id:'Tahun '+yr+' · belum diekstraksi');const pct=d.id_fdi_total_income_payments_usd_million?d.id_fdi_equity_income_payments_usd_million/d.id_fdi_total_income_payments_usd_million*100:0;$('eqbar').style.width=pct+'%';$('itbar').style.width=(d.source_id?100-pct:0)+'%';$('eqpct').textContent=d.source_id?pct.toFixed(1)+'%':'—';$('itpct').textContent=d.source_id?(100-pct).toFixed(1)+'%':'—';$('source').innerHTML=d.source_url?`Sumber: <a href="${d.source_url}" target="_blank" rel="noopener">${d.source_id} · Tabel 4, halaman PDF ${d.source_pdf_page}</a>`:'Sumber: belum ditarik untuk tahun ini';$('stock').textContent=d.sg_fdi_stock_indonesia_sgd_million_CONTEXT_NOT_INCOME!=null?'S$'+(d.sg_fdi_stock_indonesia_sgd_million_CONTEXT_NOT_INCOME/1000).toLocaleString('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2})+' miliar':'Data belum tersedia';renderBars(yr)}function renderBars(yr){const box=$('bars');box.innerHTML='';const max=Math.max(...DATA.map(d=>d.id_fdi_total_income_payments_usd_million||0));DATA.forEach(r=>{const a=document.createElement('div');a.className='yearbar'+(r.year==yr?' active':'');a.setAttribute('aria-disabled',String(!r.source_id));const b=document.createElement('div');b.className='colbar';b.style.height=r.source_id?(r.id_fdi_total_income_payments_usd_million/max*192)+'px':'4px';const tick=document.createElement('span');tick.className='tick';tick.textContent=(r.year%2==1 || r.year==2024)?String(r.year).slice(2):'';a.title=r.source_id?`${r.year}: ${currency(r.id_fdi_total_income_payments_usd_million)}`:`${r.year}: belum diekstraksi`;a.append(b,tick);a.onclick=()=>renderYear(r.year);box.append(a)})}DATA.slice().reverse().forEach(d=>{let o=document.createElement('option');o.value=d.year;o.textContent=d.year+(d.source_id?'':' • data belum diekstraksi');opt.append(o)});opt.onchange=()=>renderYear(+opt.value);$('table').innerHTML=DATA.filter(d=>d.source_id).map(d=>`<tr><td><strong>${d.year}</strong></td><td>${(d.id_fdi_equity_income_payments_usd_million/1000).toFixed(3)}</td><td>${(d.id_fdi_intercompany_interest_payments_usd_million/1000).toFixed(3)}</td><td><strong>${(d.id_fdi_total_income_payments_usd_million/1000).toFixed(3)}</strong></td><td><span class="tag ${d.bi_data_status==='provisional'?'warn':''}">${labels[d.bi_data_status]}</span></td><td><a target="_blank" rel="noopener" href="${d.source_url}#page=${d.source_pdf_page}">BI PDF hlm. ${d.source_pdf_page}</a></td></tr>`).join('');renderYear(2025);</script></body></html>'''
htmltext=htmltext.replace('__EMBEDDED_DATA__',data_json)
(BASE/'stage4_preview.html').write_text(htmltext,encoding='utf-8')
# code checks
assert 'undefined' not in htmltext
assert len(rows)==23 and len(OBS)==11
assert rows[-1]['id_fdi_total_income_payments_usd_million']==25698
assert next(r for r in rows if r['year']==2024)['sg_fdi_stock_indonesia_sgd_million_CONTEXT_NOT_INCOME']>100000
archive=Path('/mnt/data/indonesia_singapura_tahap4_pendapatan_investasi_2003_2025.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(BASE.glob('*')):
  if p.is_file(): z.write(p,arcname='stage4/'+p.name)
print(json.dumps({'archive':str(archive),'files':[(p.name,p.stat().st_size) for p in BASE.glob('*') if p.is_file()],'check':validation},ensure_ascii=False,indent=2))
