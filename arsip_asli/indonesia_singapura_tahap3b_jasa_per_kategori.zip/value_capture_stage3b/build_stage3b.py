#!/usr/bin/env python3
"""Indonesia–Singapore services category ingestion, QA, and offline HTML report.
Stdlib only.  Usage:
    python build_stage3b.py --offline
    python build_stage3b.py --download
    python build_stage3b.py --exports /path/to/M060261.csv --imports /path/to/M060271.csv
Never assigns national category numbers to Indonesia. Inputs must preserve source DataSeries.
"""
import argparse, csv, io, json, re, time, urllib.request, urllib.parse
from collections import defaultdict
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'outputs'; OUT.mkdir(parents=True,exist_ok=True)
BASE=Path('/mnt/data/value_capture_stage3/bilateral_services_singstat_2003_2025.csv')
if not BASE.exists(): BASE=ROOT/'inputs'/'bilateral_services_singstat_2003_2025.csv'
SRC={
 'exports':('M060261','d_bff5c93e3d5a7153df64a968afcc7d5b','https://data.gov.sg/datasets/d_bff5c93e3d5a7153df64a968afcc7d5b/view'),
 'imports':('M060271','d_addeac819bfa848fdcc255dd6637484c','https://data.gov.sg/datasets/d_addeac819bfa848fdcc255dd6637484c/view')
}
CATEGORIES=[
 ('manufacturing_on_others_inputs','Manufaktur atas input milik pihak lain',r'manufacturing services on physical inputs owned by others'),
 ('maintenance_repair','Pemeliharaan dan perbaikan',r'maintenance and repair'),
 ('transport','Transportasi',r'^transport$'),
 ('travel','Perjalanan',r'^travel$'),
 ('construction','Konstruksi',r'^construction$'),
 ('insurance','Asuransi',r'^insurance'),
 ('financial','Jasa keuangan',r'^financial'),
 ('telecom_computer_information','Telekomunikasi, komputer dan informasi',r'^telecommunications?.*computer.*information'),
 ('intellectual_property','Penggunaan hak kekayaan intelektual',r'^charges for the use of intellectual property'),
 ('other_business','Jasa bisnis lainnya',r'^other business services$'),
 ('personal_cultural_recreational','Jasa personal, budaya dan rekreasi',r'^personal.*cultural.*recreational'),
 ('government','Jasa pemerintah',r'^government goods.*services|^government services')
]
def norm(s):
    return re.sub(r'\s+',' ',str(s).strip().lower().replace('&','and').replace('–','-').replace('—','-')).strip()
def which(s):
    s=norm(s)
    for key,label,pattern in CATEGORIES:
        if re.search(pattern,s): return key
    return None

def number(value):
    s=str(value or '').strip().replace(',','')
    if not s or s.lower() in ('na','n.a.','..','-','null','none','suppressed','nan'): return None
    try:return float(s)
    except ValueError:return None

def getfield(row,year):
    for k,v in row.items():
        if str(k).strip().lower() in (str(year),str(year)+' numeric',str(year)+' text'):return v
    return None

def readfile(path):
    path=Path(path)
    if path.suffix.lower()=='.json':
        obj=json.loads(path.read_text(encoding='utf-8-sig'))
        if isinstance(obj,list):return obj
        for name in ['records','rows']:
            if isinstance(obj.get(name),list):return obj[name]
        for key in ['data','result']:
            block=obj.get(key,{})
            if isinstance(block,dict):
                for name in ('records','rows'):
                    if isinstance(block.get(name),list): return block[name]
        raise ValueError('JSON does not contain records/rows')
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def read_json_url(url,timeout=18):
    req=urllib.request.Request(url,headers={'User-Agent':'PublicEconomicResearch/1.0', 'Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)

def fetch_rows(code):
    dataset_id=SRC[code][1]
    # public API, not scraping; do not bypass paywalls or access restrictions
    errors=[]
    url=f'https://api-production.data.gov.sg/v2/public/api/datasets/{dataset_id}/list-rows'
    try:
        rows=[]
        for _ in range(15):
            payload=read_json_url(url); b=payload.get('data',{})
            batch=b.get('rows',[])
            if not isinstance(batch,list):raise ValueError('Invalid v2 rows shape')
            rows.extend(batch)
            nxt=b.get('links',{}).get('next')
            if not nxt or not batch: break
            url=urllib.parse.urljoin('https://api-production.data.gov.sg',nxt)
            time.sleep(.5)
        if len(rows)>100:return rows,'v2_list_rows'
        errors.append('v2 returned fewer than 100 rows')
    except Exception as e: errors.append('v2: '+str(e))
    try:
        rows=[]
        for offset in range(0,1000,100):
            params=urllib.parse.urlencode({'resource_id':dataset_id,'limit':100,'offset':offset})
            obj=read_json_url('https://data.gov.sg/api/action/datastore_search?'+params)
            result=obj.get('result',{})
            batch=result.get('records',[])
            rows+=batch
            if len(rows)>=result.get('total',999999) or not batch: break
            time.sleep(.6)
        if len(rows)>100:return rows,'legacy_datastore_search'
        errors.append('legacy returned fewer than 100 rows')
    except Exception as e:errors.append('legacy: '+str(e))
    try:
        u=f'https://api-open.data.gov.sg/v1/public/api/datasets/{dataset_id}/initiate-download'
        read_json_url(u)
        time.sleep(1)
        obj=read_json_url(f'https://api-open.data.gov.sg/v1/public/api/datasets/{dataset_id}/poll-download')
        download_url=obj.get('data',{}).get('url')
        if download_url:
            req=urllib.request.Request(download_url,headers={'User-Agent':'PublicEconomicResearch/1.0'})
            with urllib.request.urlopen(req,timeout=25) as rsp:
                content=rsp.read().decode('utf-8-sig')
            rows=list(csv.DictReader(io.StringIO(content)))
            if len(rows)>100:return rows,'public_poll_download'
        errors.append('download did not yield complete data')
    except Exception as e:errors.append('download: '+str(e))
    raise RuntimeError('; '.join(errors))

def extract_indonesia(rows):
    if not rows:raise ValueError('Empty dataset')
    def label(r):
        for key in r:
            if norm(key).replace(' ','') in ('dataseries','series','dataseriestext','dataseriesnumeric'):
                return str(r[key]).strip()
        return str(next(iter(r.values())))
    # Two supported encodings: country header row then category children; or prefixed country-category labels.
    hits=[i for i,r in enumerate(rows) if norm(label(r))=='indonesia']
    if not hits:
        pref=[r for r in rows if re.match(r'^indonesia\s*[-:/>]\s*',norm(label(r)))]
        if not pref:raise ValueError('No Indonesia series header found. Inspect DataSeries hierarchy manually.')
        entries=[]
        for row in pref:
            cat=which(re.sub(r'^indonesia\s*[-:/>]\s*','',norm(label(row))))
            if cat:entries.append((cat,row))
        total=None
    else:
        i=hits[0];total=rows[i];entries=[]
        for r in rows[i+1:i+24]:
            cat=which(label(r))
            if cat:entries.append((cat,r))
            elif entries:break
            else:break
    result={}
    for cat,row in entries:
        if cat in result:raise ValueError('Duplicate category: '+cat)
        result[cat]={y:number(getfield(row,y)) for y in range(2000,2025)}
    if len(result)<10:raise ValueError(f'Only {len(result)} category rows detected, expected approximately 12; do not publish unsound attribution')
    return {'categories':result,'total':{y:number(getfield(total,y)) for y in range(2000,2025)} if total else {},'category_count':len(result),'name':'Indonesia'}

def csv_write(path,fields,rows):
    with Path(path).open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');wr.writeheader();wr.writerows(rows)

def baseline():
    if not BASE.exists():raise FileNotFoundError('Missing Stage 3A baseline. Copy into inputs/ or use same /mnt/data workspace.')
    rows=readfile(BASE)
    return {int(r['year']):{
        'year':int(r['year']),
        'exports':number(r['sg_services_exports_to_id_million_sgd']),
        'imports':number(r['sg_services_imports_from_id_million_sgd']),
        'balance':number(r['sg_services_balance_million_sgd']),
        'reported_status':r.get('data_status','')
    } for r in rows}

# numeric differences may occur due to statistical availability/compilation and rounding
TOLERANCE_MILLION_SGD=1.5

def run(export_rows=None,import_rows=None,source_mode='offline'):
    base=baseline()
    extracted={}
    for code,records in [('exports',export_rows),('imports',import_rows)]:
        if records:
            extracted[code]=extract_indonesia(records)
    long=[];checks=[];categories=[]
    for year in range(2003,2026):
        b=base.get(year,dict(year=year,exports=None,imports=None,balance=None))
        m={}
        for typ in ('exports','imports'):
            rows=extracted.get(typ,{}).get('categories',{})
            observed={k:r.get(year) for k,r in rows.items()}
            sumval=sum(x for x in observed.values() if x is not None) if observed and all(v is not None for v in observed.values()) and len(observed)==len(CATEGORIES) else None
            ref=b.get(typ)
            delta=round(sumval-ref,3) if sumval is not None and ref is not None else None
            passed=(abs(delta)<=TOLERANCE_MILLION_SGD) if delta is not None else False
            m[typ]={'total_3a':ref,'category_sum':round(sumval,3) if sumval is not None else None,'delta':delta,'passed':passed,'category_count':len(observed),'status':'reconciled' if passed else 'missing_or_failed'}
        both_passed= m['exports']['passed'] and m['imports']['passed']
        checks.append({'year':year,'reported_exports_million_sgd':b.get('exports'),'category_exports_sum':m['exports']['category_sum'],'exports_difference':m['exports']['delta'],'exports_reconciled':m['exports']['passed'],'reported_imports_million_sgd':b.get('imports'),'category_imports_sum':m['imports']['category_sum'],'imports_difference':m['imports']['delta'],'imports_reconciled':m['imports']['passed'],'year_reconciled':both_passed,'notes':'2025 bilateral unavailable' if year==2025 else ('Category data not yet collected' if len(extracted)<2 else 'See QA flags')})
        for key,label,_ in CATEGORIES:
            ex=extracted.get('exports',{}).get('categories',{}).get(key,{}).get(year)
            im=extracted.get('imports',{}).get('categories',{}).get(key,{}).get(year)
            # Publish only fully matched partner/year series, never substitute Singapore world/Asia values
            long.append({'year':year,'partner':'Indonesia','reporter':'Singapore','category_id':key,'category_label':label,'sg_exports_million_sgd':ex,'sg_imports_million_sgd':im,'sg_balance_million_sgd':round(ex-im,3) if ex is not None and im is not None else None,'source_exports_table':'M060261','source_imports_table':'M060271','status':'official_extracted_reconciled' if both_passed and ex is not None and im is not None else ('extracted_unreconciled' if ex is not None or im is not None else 'pending_extract'),'year_total_reconciled':both_passed,'is_profit':False,'is_value_added':False})
        categories.append({'year':year,'total_3a':b,'categories':[{k:v for k,v in r.items() if k!='year'} for r in long[-len(CATEGORIES):]],'qa':m,'verified':both_passed})
    csv_write(OUT/'stage3b_services_category_long_2003_2025.csv',list(long[0]),long)
    csv_write(OUT/'stage3b_reconciliation_2003_2025.csv',list(checks[0]),checks)
    summary={'stage':'3B','created':datetime.now(ZoneInfo('Asia/Jakarta')).date().isoformat(),'source_mode':source_mode,'sector_data_available':bool(extracted),'fully_reconciled_years':sum(x['year_reconciled'] for x in checks),'period':'2003–2025','confirmed_bilateral_years':'2003–2024','categories':[{'id':k,'label':label} for k,label,_ in CATEGORIES],'sources':{k:{'table':v[0],'dataset_id':v[1],'url':v[2]} for k,v in SRC.items()},'note':'Services trade measures transactions, not profit nor retained value added; official category data pending unless verified and reconciled.'}
    (OUT/'stage3b_status.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    dashboard_data={'summary':summary,'data':categories}
    (OUT/'stage3b_dashboard_data.json').write_text(json.dumps(dashboard_data,ensure_ascii=False,indent=2),encoding='utf-8')
    produce_html(dashboard_data)
    return summary

def produce_html(d):
    payload=json.dumps(d,ensure_ascii=False).replace('</','<\\/')
    html=HTML_TEMPLATE.replace('___JSON_PAYLOAD___',payload)
    (OUT/'stage3b_preview.html').write_text(html,encoding='utf-8')

HTML_TEMPLATE=r'''<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Stage 3B | Indonesia—Singapore Economic Value Capture</title>
<style>:root{--bg:#f5f7f6;--navy:#101d2a;--teal:#1b8990;--gold:#d7a052;--muted:#647583;--border:#dce4e6}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--navy);font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}a{color:#167982}a:hover{text-decoration:none}.shell{max-width:1180px;margin:auto;padding:0 26px 60px}.mast{background:var(--navy);color:white;padding:16px 0}.mast .shell{padding-bottom:0;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}.mast b{letter-spacing:.14em;font-size:13px}.small{font-size:12px;color:var(--muted)}.mast .small{color:#9bb2c2}.top{padding:38px 0 12px}.eyebrow{color:var(--teal);font-size:11px;font-weight:800;letter-spacing:.18em;text-transform:uppercase}h1{font-size:clamp(31px,4.8vw,56px);line-height:1.09;letter-spacing:-.045em;margin:10px 0 14px;max-width:920px}h2{font-size:24px;letter-spacing:-.025em;margin:0 0 12px}.lead{max-width:860px;color:#465b68;font-size:16px}.tools{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:26px 0}.tools select{border:1px solid var(--border);border-radius:10px;padding:10px 16px;font-weight:700;background:#fff;color:var(--navy);font:inherit}.pill{background:#fdf0d9;color:#86642c;border-radius:30px;padding:6px 12px;font-size:12px;font-weight:700}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.card,.panel{border:1px solid var(--border);border-radius:16px;background:#fff;box-shadow:0 5px 25px rgba(16,29,42,.025)}.card{padding:24px}.card .val{font-size:35px;line-height:1.2;letter-spacing:-.03em;font-weight:750;margin:9px 0}.card .label{color:var(--muted);font-size:12px;font-weight:650}.panel{margin-top:18px;padding:24px}.viz{width:100%;height:auto;overflow:visible}.legend{display:flex;gap:18px;flex-wrap:wrap;margin-top:10px}.legend span:before{content:' ';display:inline-block;width:10px;height:10px;background:var(--teal);border-radius:2px;margin-right:6px}.legend span:nth-child(2):before{background:var(--gold)}table{width:100%;border-collapse:collapse}th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #e9eef0;font-size:13px}th{color:#546875;background:#f8faf9}td.num{text-align:right;font-variant-numeric:tabular-nums}th.num{text-align:right}.muted{color:var(--muted)}.empty{font-size:13px;color:#916e32}.notice{padding:13px 17px;background:#f9f4e8;border:1px solid #ecdcb8;border-radius:12px;color:#6a5632}.footer{color:#617582;margin:35px 0 0;border-top:1px solid #dce4e6;padding-top:20px;font-size:12px}.grid2{display:grid;grid-template-columns:1.3fr 1fr;gap:18px}.bar-bg{height:10px;background:#eaf0f0;border-radius:10px;overflow:hidden}.bar-bg>div{height:100%;background:#1b8990}button{cursor:pointer;background:var(--navy);color:white;border:0;border-radius:9px;padding:10px 15px;font-weight:700}button:hover{background:#244459}@media(max-width:720px){.shell{padding-left:16px;padding-right:16px}.cards,.grid2{grid-template-columns:1fr}.card .val{font-size:28px}th,td{padding:8px 5px;font-size:12px}}</style></head><body>
<div class="mast"><div class="shell"><b>INDONESIA × SINGAPORE <span style="color:#71bbc0">/ VALUE CAPTURE OBSERVATORY</span></b><span class="small">RESEARCH MODULE 03B · PREVIEW</span></div></div>
<div class="shell"><div class="top"><div class="eyebrow">Economic research / jasa lintas negara</div><h1>Siapa menerima pembayaran jasa dari Indonesia?</h1><div class="lead">Perdagangan jasa bilateral: nilai transaksi, surplus historis, dan ruang untuk memeriksa kontribusi transportasi, keuangan, bisnis, perjalanan, asuransi, serta kategori lain.</div></div>
<div class="tools"><label><strong>Periode:</strong> <select id="year"></select></label><span class="pill" id="state">Status kategori: menunggu data primer</span></div>
<div class="cards"><div class="card"><div class="label">EKSPOR JASA SINGAPURA KE INDONESIA</div><div class="val" id="exp">—</div><div class="small">S$ miliar · harga berlaku</div></div><div class="card"><div class="label">IMPOR JASA SINGAPURA DARI INDONESIA</div><div class="val" id="imp">—</div><div class="small">S$ miliar · harga berlaku</div></div><div class="card"><div class="label">SURPLUS JASA SINGAPURA</div><div class="val" id="bal">—</div><div class="small">Selisih transaksi, bukan laba</div></div></div>
<div class="panel"><h2>Perdagangan jasa tahunan 2003–2024</h2><svg id="trend" viewBox="0 0 1040 320" class="viz" role="img" aria-label="Grafik ekspor dan impor jasa bilateral 2003 hingga 2024"></svg><div class="legend"><span>Ekspor jasa Singapura</span><span>Impor jasa Singapura</span></div></div>
<div class="grid2"><div class="panel"><h2>Kontribusi 12 kategori jasa</h2><div class="small" style="margin-bottom:16px">Hanya angka khusus Indonesia yang boleh masuk. Jika dataset kategori belum diekstraksi dan direkonsiliasi, nilainya sengaja dikosongkan.</div><div style="overflow:auto"><table><thead><tr><th>Jenis jasa</th><th class="num">Ekspor</th><th class="num">Impor</th><th class="num">Surplus</th></tr></thead><tbody id="rows"></tbody></table></div></div>
<div><div class="panel"><h2>Quality gate</h2><div id="qa" class="notice"></div><p class="small">Total komponen 12 kategori harus sama dengan total perdagangan jasa 3A pada tahun yang sama (toleransi pembulatan S$1,5 juta). Bila tidak cocok, status gagal validasi.</p></div><div class="panel"><h2>Audit trail</h2><p>Sumber resmi: <a target="_blank" rel="noopener" href="https://data.gov.sg/datasets/d_bff5c93e3d5a7153df64a968afcc7d5b/view">M060261 (ekspor)</a> dan <a target="_blank" rel="noopener" href="https://data.gov.sg/datasets/d_addeac819bfa848fdcc255dd6637484c/view">M060271 (impor)</a>.</p><p class="small">Rincian kategori belum ditampilkan sampai ekstraksi dari data primer berhasil. Data total bersumber dari arsip Tahap 3A.</p><button id="exportBtn">Unduh data tahun terpilih</button></div></div></div>
<div class="footer"><b>Interpretasi:</b> nilai ekspor jasa tidak sama dengan laba perusahaan, pendapatan pemegang saham, maupun nilai tambah di Singapura. Tahun 2025 belum memiliki observasi bilateral terverifikasi dalam seri yang digunakan. · Data provenance dan metodologi ada di ZIP Tahap 3B.</div></div>
<script type="application/json" id="payload">___JSON_PAYLOAD___</script><script>
(()=>{const p=JSON.parse(document.getElementById('payload').textContent);const all=p.data;const years=all.map(o=>o.year).reverse();const fmt=n=>n===null||n===undefined?'—':new Intl.NumberFormat('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2}).format(n/1000);const cfmt=n=>n===null||n===undefined?'Belum ada':new Intl.NumberFormat('id-ID',{maximumFractionDigits:1}).format(n);const select=document.getElementById('year');years.forEach(y=>{let o=document.createElement('option');o.value=y;o.textContent=y;select.append(o)});select.value='2024';
function line(vals,color){const good=vals.map((v,i)=>[i,v]).filter(([i,v])=>v!==null&&v!==undefined);const max=9300;const points=good.map(([i,v])=>`${55+i*43},${270-v/max*235}`).join(' ');return `<polyline points="${points}" fill="none" stroke="${color}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>`}
const historic=all.filter(v=>v.year<2025);const svg=document.getElementById('trend');svg.innerHTML=`${[0,2000,4000,6000,8000].map(v=>`<line x1="52" y1="${270-v/9300*235}" x2="1010" y2="${270-v/9300*235}" stroke="#e6edef"/><text x="5" y="${275-v/9300*235}" fill="#72848a" font-size="14">${(v/1000).toFixed(0)}</text>`).join('')}${line(historic.map(v=>v.total_3a.exports),'#1b8990')}${line(historic.map(v=>v.total_3a.imports),'#d7a052')}${historic.filter((v,i)=>i%3===0).map(v=>`<text x="${55+(v.year-2003)*43}" y="302" text-anchor="middle" fill="#7a8990" font-size="13">${v.year}</text>`).join('')}`;
function update(){let row=all.find(x=>String(x.year)===select.value);if(!row)return;const t=row.total_3a;document.getElementById('exp').textContent=fmt(t.exports);document.getElementById('imp').textContent=fmt(t.imports);document.getElementById('bal').textContent=fmt(t.balance);document.getElementById('state').textContent=row.verified?'Kategori sudah direkonsiliasi':'Kategori belum tervalidasi';const body=document.getElementById('rows');body.innerHTML='';row.categories.forEach(x=>{const tr=document.createElement('tr');[x.category_label,cfmt(x.sg_exports_million_sgd),cfmt(x.sg_imports_million_sgd),cfmt(x.sg_balance_million_sgd)].forEach((v,i)=>{let td=document.createElement('td');td.textContent=v;if(i)td.className='num '+(v==='Belum ada'?'empty':'');tr.append(td)});body.append(tr)});const qa=document.getElementById('qa');qa.textContent=row.verified?'LULUS: Jumlah seluruh kategori cocok dengan total 3A untuk ekspor dan impor.':'BELUM LULUS: Angka kategori Indonesia belum lengkap dan/atau belum cocok dengan total 3A. Jangan gunakan untuk peringkat sektor.'}
select.addEventListener('change',update);document.getElementById('exportBtn').addEventListener('click',()=>{let r=all.find(x=>String(x.year)===select.value);let blob=new Blob([JSON.stringify(r,null,2)],{type:'application/json'});let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='stage3b_'+select.value+'.json';a.click();URL.revokeObjectURL(a.href)});update();})();
</script></body></html>'''

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--offline',action='store_true');parser.add_argument('--download',action='store_true');parser.add_argument('--exports');parser.add_argument('--imports');args=parser.parse_args()
    rows={};method=[]
    for code in ('exports','imports'):
        local=getattr(args,code) or (ROOT/'inputs'/f'{code}_category.csv')
        if Path(local).exists(): rows[code]=readfile(local);method.append(code+':local')
        elif args.download:
            try:
                rec,how=fetch_rows(code);rows[code]=rec;method.append(code+':'+how)
                (ROOT/'inputs'/f'{code}_category_official.json').write_text(json.dumps({'records':rec},ensure_ascii=False,indent=2),encoding='utf-8')
                print(code,len(rec),'official rows received',how)
            except Exception as exc:
                print('WARNING: official API unavailable for',code,':',exc)
    status=run(rows.get('exports'),rows.get('imports'),','.join(method) if method else 'offline_pending_official_category_data')
    print(json.dumps(status,ensure_ascii=False,indent=2))
