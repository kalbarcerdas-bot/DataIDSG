"""Download structured rows from data.gov.sg public API.
Run manually from a machine with internet. This script is untested here due to no network access.
Does not attempt to circumvent access controls. Always inspect field/hierarchy before mapping Indonesia.
"""
from urllib.parse import urlencode
from urllib.request import urlopen,Request
from pathlib import Path
import json,time
DATASETS={
 'exports_services_categories':'d_bff5c93e3d5a7153df64a968afcc7d5b',
 'imports_services_categories':'d_addeac819bfa848fdcc255dd6637484c',
 'exports_industry_partner':'d_3dbf4c3eec72cfccac3ad1f75e1d3adb',
 'imports_industry_partner':'d_0267c40931b02c8cad4b56e41e6e35c7',
}
OUT=Path(__file__).parent/'official_api_downloads';OUT.mkdir(exist_ok=True)
for name,dataset_id in DATASETS.items():
    rows=[];offset=0;limit=100
    while True:
        url='https://data.gov.sg/api/action/datastore_search?'+urlencode({'resource_id':dataset_id,'limit':limit,'offset':offset})
        request=Request(url,headers={'User-Agent':'ResearchArchive/1.0 (public data; reasonable rate)'})
        with urlopen(request,timeout=30) as fp:
            response=json.load(fp)
        result=response.get('result') or {}
        batch=result.get('records',[])
        if not batch:break
        rows.extend(batch)
        offset+=len(batch)
        if offset>=result.get('total',offset):break
        time.sleep(0.5)
    (OUT/f'{name}.json').write_text(json.dumps({'dataset_id':dataset_id,'records':rows},indent=2,ensure_ascii=False),encoding='utf-8')
    print(name,'rows:',len(rows))
