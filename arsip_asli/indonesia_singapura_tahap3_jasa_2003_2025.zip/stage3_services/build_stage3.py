import csv,json,statistics,math,zipfile,html,os
from pathlib import Path
from datetime import datetime,timezone
P=Path('/mnt/data/value_capture_stage3')
# Sources: SingStat M060201, M060211. Unit SGD million. Reverse chronological official Indonesia row, 2024 .. 2000.
ex=[7857.7,7766.8,8419.1,6310.5,5423.2,6841.7,5896.4,5616,5088.6,5032,4837.1,4535.8,4062.7,3537.8,3291.1,3642.6,3321.9,3026,2969.8,2364.4,2231.8,1767.5,1801.4,1707.5,1607.9]
im=[4268.7,3386.1,3638,3364.1,2953.3,2794.5,2494.4,2245.5,2105.5,2170.2,1990.2,1920,1816.8,1733.9,1780.2,1566.5,1673.7,1587.4,1490.6,1508.9,1498.9,1126.8,1162.3,1044.6,831]
assert len(ex)==len(im)==25
EXPORT_URL='https://data.gov.sg/datasets/d_ae32bc57f36f0d99d2f892a1f3241a7b/view'
IMPORT_URL='https://data.gov.sg/datasets/d_15fff4cec9a5a41a90655a37195297ef/view'
REXP='M060201'; RIMP='M060211'
# limit to project window; all observations 2003-2024; 2025 missing.
raw={2024-i:(ex[i],im[i]) for i in range(25)}
records=[]
for y in range(2003,2026):
    e,m=raw.get(y,(None,None))
    prev=raw.get(y-1,(None,None))
    rec={
        'year':y,'partner':'Indonesia','reporter':'Singapore','currency':'SGD','unit':'million_SGD',
        'sg_services_exports_to_id_million_sgd':e,
        'sg_services_imports_from_id_million_sgd':m,
        'sg_services_balance_million_sgd':round(e-m,1) if e is not None else None,
        'sg_services_total_trade_million_sgd':round(e+m,1) if e is not None else None,
        'exports_yoy_percent':round((e/prev[0]-1)*100,2) if e is not None and prev[0] else None,
        'imports_yoy_percent':round((m/prev[1]-1)*100,2) if m is not None and prev[1] else None,
        'sg_exports_to_id_source_id':REXP,'sg_imports_from_id_source_id':RIMP,
        'sg_exports_to_id_source_url':EXPORT_URL,'sg_imports_from_id_source_url':IMPORT_URL,
        'data_status':'official_published' if e is not None else 'not_published_bilateral',
        'is_profit':False,'is_value_added':False,
        'notes':'Singapore reporter, TIS Survey. Services trade, not company profit/value added.' if e is not None else '2025 bilateral country-level series not verified; do not interpolate from total Singapore trade.'
    }
    records.append(rec)
assert len(records)==23
assert records[0]['sg_services_exports_to_id_million_sgd']==1767.5
assert records[21]['sg_services_exports_to_id_million_sgd']==7857.7
assert records[21]['sg_services_balance_million_sgd']==3589.0
assert records[22]['sg_services_exports_to_id_million_sgd'] is None

# long with simple value type and URLs
long=[]
for r in records:
  for metric,field,sid,url in [
      ('sg_services_exports_to_id','sg_services_exports_to_id_million_sgd',REXP,EXPORT_URL),
      ('sg_services_imports_from_id','sg_services_imports_from_id_million_sgd',RIMP,IMPORT_URL),
      ('sg_services_trade_balance','sg_services_balance_million_sgd',f'{REXP},{RIMP}',EXPORT_URL+' ; '+IMPORT_URL)]:
    long.append({'year':r['year'],'reporter':'Singapore','partner':'Indonesia','metric_id':metric,'value_million_sgd':r[field],
                 'unit':'million_SGD','source_table_id':sid,'source_url':url,
                 'observation_status':r['data_status'] if r[field] is not None else 'not_available',
                 'is_investment_income':False,'is_value_added':False})

def csv_dump(name,rows,headers=None):
    with open(P/name,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers or list(rows[0].keys()), extrasaction='ignore');w.writeheader();w.writerows(rows)

csv_dump('bilateral_services_singstat_2003_2025.csv',records)
csv_dump('bilateral_services_long_2003_2025.csv',long)
# full 2000-2024 sample (as extracted, not raw publisher CSV)
full=[{'year':y,'sg_services_exports_to_id_million_sgd':raw[y][0],'sg_services_imports_from_id_million_sgd':raw[y][1],'sg_services_balance_million_sgd':round(raw[y][0]-raw[y][1],1)} for y in range(2000,2025)]
csv_dump('bilateral_services_full_2000_2024.csv',full)

category_sources=[
  {'series_id':'M060261','dataset_id':'d_bff5c93e3d5a7153df64a968afcc7d5b','direction':'SG_EXPORTS_TO_INDONESIA','url':'https://data.gov.sg/datasets/d_bff5c93e3d5a7153df64a968afcc7d5b/view','available_range':'2000-2024','extraction_status':'not_extracted'},
  {'series_id':'M060271','dataset_id':'d_addeac819bfa848fdcc255dd6637484c','direction':'SG_IMPORTS_FROM_INDONESIA','url':'https://data.gov.sg/datasets/d_addeac819bfa848fdcc255dd6637484c/view','available_range':'2000-2024','extraction_status':'not_extracted'},
  {'series_id':'M060361','dataset_id':'d_3dbf4c3eec72cfccac3ad1f75e1d3adb','direction':'SG_EXPORTS_TO_INDONESIA_BY_INDUSTRY','url':'https://data.gov.sg/datasets/d_3dbf4c3eec72cfccac3ad1f75e1d3adb/view','available_range':'2017-2024','extraction_status':'not_extracted'},
  {'series_id':'M060371','dataset_id':'d_0267c40931b02c8cad4b56e41e6e35c7','direction':'SG_IMPORTS_FROM_INDONESIA_BY_INDUSTRY','url':'https://data.gov.sg/datasets/d_0267c40931b02c8cad4b56e41e6e35c7/view','available_range':'2017-2024','extraction_status':'not_extracted'},
]
csv_dump('category_sector_source_registry.csv',category_sources)
category_names=['Manufacturing services on physical inputs owned by others','Maintenance and repair services','Transport','Travel','Insurance','Government goods and services','Construction','Financial','Telecommunications, computer and information','Charges for the use of intellectual property','Personal, cultural and recreational','Other business services']
with open(P/'services_category_template.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f); w.writerow(['year','direction','service_category','value_million_sgd','unit','source_id','verification_status','notes'])
    for year in range(2003,2026):
        for d,sid in [('SG_EXPORTS_TO_INDONESIA','M060261'),('SG_IMPORTS_FROM_INDONESIA','M060271')]:
            for cat in category_names:
                w.writerow([year,d,cat,'','million_SGD',sid,'not_extracted' if year<=2024 else 'bilateral_unpublished',''])

period=[r for r in records if r['year']<=2024]
cume=round(sum(r['sg_services_exports_to_id_million_sgd'] for r in period),1)
cumi=round(sum(r['sg_services_imports_from_id_million_sgd'] for r in period),1)
cumb=round(cume-cumi,1)
ex2003=records[0]['sg_services_exports_to_id_million_sgd']; ex2024=records[21]['sg_services_exports_to_id_million_sgd']
im2003=records[0]['sg_services_imports_from_id_million_sgd']; im2024=records[21]['sg_services_imports_from_id_million_sgd']
cagr_ex=round(((ex2024/ex2003)**(1/21)-1)*100,2)
cagr_im=round(((im2024/im2003)**(1/21)-1)*100,2)
all_positive=sum(r['sg_services_balance_million_sgd']>0 for r in period)
maxsur=max(period,key=lambda r:r['sg_services_balance_million_sgd'])
summary={'title':'Indonesia–Singapore Value Capture Observatory · Phase 3 Services Trade','reporter':'Singapore',
         'years_in_panel':'2003-2025','observed_years':'2003-2024','last_observed_year':2024,
         'observed_n':len(period),'missing_n':1,'currency':'SGD','values_unit':'million_SGD',
         'exports_2024_million_sgd':ex2024,'imports_2024_million_sgd':im2024,'surplus_2024_million_sgd':round(ex2024-im2024,1),
         'cumulative_exports_2003_2024_million_sgd':cume,'cumulative_imports_2003_2024_million_sgd':cumi,
         'cumulative_balance_2003_2024_million_sgd':cumb,'export_cagr_2003_2024_percent':cagr_ex,'import_cagr_2003_2024_percent':cagr_im,
         'positive_singapore_balance_years':all_positive,
         'highest_surplus_year':maxsur['year'],'highest_surplus_million_sgd':maxsur['sg_services_balance_million_sgd'],
         'is_value_capture_estimate':False,
         'methodology':'Sum of annual recorded nominal bilateral services receipts/payments; includes gross transactions, NOT GDP value added, net profit or beneficiaries.',
         'sources':{'M060201':EXPORT_URL,'M060211':IMPORT_URL},
         'source_extraction':'Manual transcription from visible Indonesia data row in data.gov.sg explorer; official source publication has not been downloaded as raw CSV in this execution. Metadata and all 25 values checked by matching year order.'}
(P/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'bilateral_services_singstat_2003_2025.json').write_text(json.dumps({'metadata':summary,'observations':records},ensure_ascii=False,indent=2),encoding='utf-8')
(P/'services_categories_registry.json').write_text(json.dumps(category_sources,ensure_ascii=False,indent=2),encoding='utf-8')
source_regs=[{'source_id':'M060201','title':'Exports Of Services By Major Trading Partner, Annual','source_url':EXPORT_URL,'dataset_id':'d_ae32bc57f36f0d99d2f892a1f3241a7b','data_last_updated':'2026-02-26','country':'Indonesia','metric':'SG exports of services to Indonesia','unit':'SGD million','period':'2000-2024','verification':'visible_singstat_data_explorer'},
             {'source_id':'M060211','title':'Imports Of Services By Major Trading Partner, Annual','source_url':IMPORT_URL,'dataset_id':'d_15fff4cec9a5a41a90655a37195297ef','data_last_updated':'2026-02-26','country':'Indonesia','metric':'SG imports of services from Indonesia','unit':'SGD million','period':'2000-2024','verification':'visible_singstat_data_explorer'}]
csv_dump('source_registry.csv',source_regs)

(P/'RESEARCH_REPORT.md').write_text(f'''# Tahap 3 — Perdagangan Jasa Bilateral Indonesia–Singapura

Dibuat: 2026-10-24. Periode utama: **2003–2025**. Ketersediaan bilateral terverifikasi: **2003–2024**.

## Angka utama (SGD juta, harga berlaku)

- Ekspor jasa Singapura ke Indonesia 2024: **{ex2024:,.1f}**.
- Impor jasa Singapura dari Indonesia 2024: **{im2024:,.1f}**.
- Surplus jasa Singapura 2024: **{ex2024-im2024:,.1f}**.
- Akumulasi ekspor 2003–2024: **{cume:,.1f}**.
- Akumulasi impor 2003–2024: **{cumi:,.1f}**.
- Akumulasi selisih 2003–2024: **{cumb:,.1f}**.
- CAGR ekspor: **{cagr_ex}%**, CAGR impor: **{cagr_im}%** (21 interval tahunan).
- Saldo positif untuk Singapura dalam **{all_positive} dari 22 tahun**.
- Tahun saldo positif tertinggi: **{maxsur['year']}** (S${maxsur['sg_services_balance_million_sgd']:,.1f} juta).

## Definisi dan batasan

1. Sudut pandang **Singapore reporter**: `exports` adalah jasa yang diberikan residen SG ke residen Indonesia; `imports` kebalikannya.
2. Data nominal dalam **SGD juta**, **bukan USD** dan bukan perdagangan barang.
3. `surplus = exports - imports`, bukan laba dan bukan jumlah value capture pemegang saham.
4. SingStat mengukur transaksi layanan lintas residen; kategori biaya layanan mencakup perjalanan, transportasi, keuangan, bisnis, IP dan lain-lain. Pemeriksaan kategori Indonesia dilakukan tersendiri.
5. Data 2025 untuk mitra Indonesia *tidak tersedia dalam seri M060201/M060211 yang diperiksa*; nilai null tetap null.
6. Jumlah lintas tahun adalah akumulasi **nominal**, bukan nilai riil (belum disesuaikan inflasi/kurs).
7. Angka diekstraksi dari baris Indonesia yang terlihat pada data explorer SingStat; file CSV penerbit asli belum diambil melalui download API, sehingga metadata menyebut bentuk transkripsi dan perlu direkonsiliasi bila CSV asli tersedia.
8. SingStat technical note menjelaskan bahwa sebagian sumber tambahan statistik jasa tidak memiliki pemisahan mitra negara. Karenanya data bilateral bisa berbeda cakupannya dari agregat nasional.

## Sumber primer

- SingStat M060201: {EXPORT_URL}
- SingStat M060211: {IMPORT_URL}
- SingStat kategori ekspor M060261: {category_sources[0]['url']}
- SingStat kategori impor M060271: {category_sources[1]['url']}
- SingStat industri ekspor M060361: {category_sources[2]['url']}
- SingStat industri impor M060371: {category_sources[3]['url']}
- Penjelasan metodologi SingStat: https://www.singstat.gov.sg/find-data/explore-data-themes/trade-investment/trade-in-services/our-data-explained

## Rencana Tahap 3B

1. Unduh empat CSV resmi kategori/industri dari data.gov.sg (via API publik atau ekspor CSV, tidak perlu Scrapling jika API berhasil).
2. Ekstrak hanya Indonesia, pertahankan relasi parent/child kategori secara eksplisit.
3. Rekonsiliasi total 2024: ekspor 7,857.7 dan impor 4,268.7 SGD juta. Jika ada selisih, jelaskan cakupan statistik, tanpa mengisi data sendiri.
4. Kategorikan transport, travel, financial, insurance, business, telekomunikasi, IP. Jangan menggunakan agregat global Singapura sebagai pengganti angka bilateral.
5. Uji aktivitas trading-related services dan nilai tambah tersendiri; hindari double counting terhadap komoditas maupun FDI.
6. Lakukan mirror comparison dengan data Indonesia/OECD BaTIS menggunakan kurs yang konsisten dan cakupan statistik yang dicatat.

## Struktur data

- `bilateral_services_singstat_2003_2025.csv`: panel utama (22 tahun observasi + 2025 NA).
- `bilateral_services_long_2003_2025.csv`: format tidy untuk chart.
- `bilateral_services_full_2000_2024.csv`: tambahan observasi 2000–2002 untuk konteks.
- `bilateral_services_singstat_2003_2025.json`: website feed.
- `category_sector_source_registry.csv`: seri yang masih perlu diambil.
- `services_category_template.csv`: template eksplisit kosong, **BUKAN data numerik**.
- `stage3_preview.html`: halaman HTML lokal dengan data internal yang bisa dibaca offline.
''',encoding='utf-8')

# Public API fetch script: provisioned as optional manual step when 3B begins, not executed
(P/'fetch_singstat_categories.py').write_text('''"""Download structured rows from data.gov.sg public API.
Run manually from a machine with internet. This script is untested here due to no network access.
Does not attempt to circumvent access controls. Always inspect field/hierarchy before mapping Indonesia.
"""
from urllib.parse import urlencode
from urllib.request import urlopen,Request
from pathlib import Path
import json,time
DATASETS={
 'exports_services_categories':'d_bff5c93e3d5a7153df64a968afcc7d5b',
 'imports_services_categories':'d_addeac819bfa848fdcc255dd6637484c',
 'exports_industry_partner':'d_3dbf4c3eec72cfccac3ad1f75e1d3adb',
 'imports_industry_partner':'d_0267c40931b02c8cad4b56e41e6e35c7',
}
OUT=Path(__file__).parent/'official_api_downloads';OUT.mkdir(exist_ok=True)
for name,dataset_id in DATASETS.items():
    rows=[];offset=0;limit=100
    while True:
        url='https://data.gov.sg/api/action/datastore_search?'+urlencode({'resource_id':dataset_id,'limit':limit,'offset':offset})
        request=Request(url,headers={'User-Agent':'ResearchArchive/1.0 (public data; reasonable rate)'})
        with urlopen(request,timeout=30) as fp:
            response=json.load(fp)
        result=response.get('result') or {}
        batch=result.get('records',[])
        if not batch:break
        rows.extend(batch)
        offset+=len(batch)
        if offset>=result.get('total',offset):break
        time.sleep(0.5)
    (OUT/f'{name}.json').write_text(json.dumps({'dataset_id':dataset_id,'records':rows},indent=2,ensure_ascii=False),encoding='utf-8')
    print(name,'rows:',len(rows))
''',encoding='utf-8')

# Single-file HTML preview: use embedded records for direct offline view
safe_payload=json.dumps(records,ensure_ascii=False).replace('<','\\u003c')
html_doc='''<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Tahap 3 — Indonesia × Singapore | Services</title>
<style>
:root{--navy:#101D2A;--teal:#1B8990;--amber:#D7A052;--bg:#F5F7F6;--ink:#162b38;--muted:#5c6b72;--line:#dbe3e2}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 ui-sans-serif,system-ui,Segoe UI,Arial}main{max-width:1100px;margin:auto;padding:35px 22px 70px}
header{background:var(--navy);color:white;padding:26px 0}.head{max-width:1100px;margin:auto;padding:0 22px}.eyebrow{font-size:11px;letter-spacing:.15em;font-weight:800;color:#9dd0d1}h1{font-size:clamp(27px,4vw,43px);line-height:1.1;margin:9px 0 12px}h2{font-size:22px}p{margin:9px 0}.light{color:#cfdbde}.sub{color:var(--muted)}
.tag{display:inline-flex;font-size:11px;font-weight:700;padding:5px 10px;border:1px solid #8aabae;border-radius:99px;color:#c2ebec}
.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:26px 0}.card{border:1px solid var(--line);border-radius:15px;background:white;padding:21px}.card .eyebrow{color:var(--muted);letter-spacing:.05em}.value{font-size:clamp(24px,3vw,33px);font-weight:800;margin:5px 0 0;letter-spacing:-.03em}.meta{font-size:12px;color:var(--muted)}
.controls{display:flex;gap:14px;align-items:center;flex-wrap:wrap;padding:15px 0}.controls label{font-weight:700;font-size:13px}.controls select,.controls button{padding:8px 11px;background:#fff;border:1px solid #abbab9;border-radius:8px;font:inherit;color:var(--ink);cursor:pointer}
.graph{background:white;border:1px solid var(--line);border-radius:14px;padding:15px}.graph svg{width:100%;height:auto;display:block} .legend{display:flex;gap:18px;flex-wrap:wrap;font-size:12px}.swatch{display:inline-block;width:13px;height:3px;vertical-align:middle;margin-right:7px}.table-scroll{overflow:auto;border-radius:12px;border:1px solid var(--line)}table{width:100%;border-collapse:collapse;background:white}td,th{padding:9px 12px;text-align:right;white-space:nowrap;border-bottom:1px solid #e8eceb}th{background:#e9efee;font-size:12px;color:#354d52}td:first-child,th:first-child{text-align:left}tr:hover td{background:#f3faf9}.note{background:#edf2f1;border-left:4px solid var(--teal);padding:14px 17px;border-radius:6px;font-size:13px}.source a{color:#156c74} footer{margin-top:36px;font-size:12px;color:var(--muted)}
@media(max-width:640px){.metrics{grid-template-columns:1fr}.card{padding:16px}.graph{padding:6px}}
</style></head><body>
<header><div class="head"><div class="eyebrow">INDONESIA × SINGAPORE · VALUE CAPTURE OBSERVATORY</div>
<h1>Perdagangan jasa bilateral</h1><p class="light">Riset Tahap 3 · Rekaman tahunan SingStat · 2003–2024</p><div class="tag">GROSS TRANSACTION DATA · NOT PROFIT</div></div></header>
<main><p class="sub">Angka berdasarkan perspektif Singapura dalam <b>miliar dolar Singapura (SGD)</b>. 2025 belum tersedia menurut negara mitra pada seri yang diperiksa.</p>
<div class="controls"><label for="yearSelect">Tahun pengamatan</label><select id="yearSelect"></select><label for="modeSelect">Grafik</label><select id="modeSelect"><option value="both">Ekspor & impor</option><option value="balance">Surplus jasa Singapura</option></select></div>
<div class="metrics"><section class="card"><div class="eyebrow">EKSPOR JASA SG → ID</div><div class="value" id="expValue">—</div><div class="meta">Penjualan jasa oleh residen Singapura</div></section><section class="card"><div class="eyebrow">IMPOR JASA SG ← ID</div><div class="value" id="impValue">—</div><div class="meta">Pembelian jasa Singapura dari Indonesia</div></section><section class="card"><div class="eyebrow">SALDO PERDAGANGAN JASA SG</div><div class="value" id="netValue">—</div><div class="meta">Ekspor – impor, bukan laba bersih</div></section></div>
<section class="graph"><div id="plot"></div><div class="legend"><span><i class="swatch" style="background:#1B8990"></i>Ekspor jasa SG ke ID</span><span><i class="swatch" style="background:#D7A052"></i>Impor jasa SG dari ID</span><span class="meta" id="plotStatus"></span></div></section>
<h2>Riwayat tahunan</h2><div class="table-scroll"><table id="dataTable"><thead><tr><th>Tahun</th><th>Ekspor jasa SG → ID (S$ miliar)</th><th>Impor jasa SG ← ID (S$ miliar)</th><th>Surplus Singapura (S$ miliar)</th></tr></thead><tbody></tbody></table></div>
<h2>Catatan metode</h2><div class="note"><b>Penting:</b> Surplus jasa menunjukkan perbedaan nilai transaksi, bukan margin keuntungan perusahaan, kontribusi pada PDB, atau nilai yang diterima pemilik akhir. Angka nominal belum disesuaikan inflasi. Kategori jasa dan industri masih harus diekstraksi dan direkonsiliasi dalam Tahap 3B.</div>
<h2>Sumber primer</h2><ul class="source"><li><a href="https://data.gov.sg/datasets/d_ae32bc57f36f0d99d2f892a1f3241a7b/view" target="_blank" rel="noreferrer">SingStat M060201: Exports of Services by Major Trading Partner</a></li><li><a href="https://data.gov.sg/datasets/d_15fff4cec9a5a41a90655a37195297ef/view" target="_blank" rel="noreferrer">SingStat M060211: Imports of Services by Major Trading Partner</a></li><li><a href="https://www.singstat.gov.sg/find-data/explore-data-themes/trade-investment/trade-in-services/our-data-explained" target="_blank" rel="noreferrer">SingStat: metodologi perdagangan jasa</a></li></ul>
<footer>INDONESIA–SINGAPORE ECONOMIC VALUE CAPTURE OBSERVATORY · STAGE 3 PREVIEW · 24 OCT 2026</footer></main>
<script>const D=__DATA__;const select=document.getElementById('yearSelect');const fmt=n=>n==null?'N/A':'S$'+(n/1000).toFixed(2)+' M';
D.slice().reverse().forEach(r=>{const e=document.createElement('option');e.value=r.year;e.textContent=r.year+(r.year===2025?' · data belum ada':'');select.appendChild(e)});select.value='2024';
function draw(){let year=Number(select.value),r=D.find(x=>x.year===year);document.getElementById('expValue').textContent=fmt(r.sg_services_exports_to_id_million_sgd);document.getElementById('impValue').textContent=fmt(r.sg_services_imports_from_id_million_sgd);document.getElementById('netValue').textContent=fmt(r.sg_services_balance_million_sgd);let valid=D.filter(x=>x.sg_services_exports_to_id_million_sgd!=null),mode=document.getElementById('modeSelect').value;
let W=1000,H=345,L=61,R=20,T=20,B=48,plotW=W-L-R,plotH=H-T-B;let ymax=mode==='both'?9000:5500;let x=(y)=>L+(y-2003)/21*plotW, yy=(v)=>T+plotH-v/ymax*plotH;
let t='<svg viewBox="0 0 1000 345" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Grafik historis jasa 2003 sampai 2024">';
for(let j=0;j<=4;j++){let yv=ymax*j/4; t+=`<line x1="${L}" x2="${W-R}" y1="${yy(yv)}" y2="${yy(yv)}" stroke="#e3e9e8"/><text x="${L-12}" y="${yy(yv)+4}" text-anchor="end" fill="#60757a" font-size="13">${(yv/1000).toFixed(1)}</text>`}
for(let yr=2003;yr<=2024;yr+=3){t+=`<text x="${x(yr)}" y="${H-19}" text-anchor="middle" fill="#60757a" font-size="12">${yr}</text>`}
const line=(key,color)=>{let pts=valid.map(a=>x(a.year)+','+yy(a[key])).join(' ');t+=`<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>`};
if(mode==='both'){line('sg_services_exports_to_id_million_sgd','#1B8990');line('sg_services_imports_from_id_million_sgd','#D7A052')}else{line('sg_services_balance_million_sgd','#1B8990')}
if(year<=2024){let col=mode==='both'?r.sg_services_exports_to_id_million_sgd:r.sg_services_balance_million_sgd;t+=`<line x1="${x(year)}" y1="${T}" x2="${x(year)}" y2="${H-B}" stroke="#101D2A" stroke-opacity=".25" stroke-dasharray="4 4"/><circle cx="${x(year)}" cy="${yy(col)}" r="6" fill="#1B8990" stroke="white" stroke-width="2"/>`}
t+='</svg>';document.getElementById('plot').innerHTML=t;document.getElementById('plotStatus').textContent=mode==='balance'?'Mode: neraca jasa Singapura':'';}
select.addEventListener('change',draw);document.getElementById('modeSelect').addEventListener('change',draw);
let tbody=document.querySelector('#dataTable tbody');D.slice().reverse().forEach(r=>{let tr=document.createElement('tr');let values=[r.year,r.sg_services_exports_to_id_million_sgd,r.sg_services_imports_from_id_million_sgd,r.sg_services_balance_million_sgd];values.forEach((v,i)=>{let td=document.createElement('td');td.textContent=i? v==null?'N/A':(v/1000).toFixed(3):String(v);tr.appendChild(td)});tbody.appendChild(tr)});draw();</script></body></html>'''.replace('__DATA__',safe_payload)
(P/'stage3_preview.html').write_text(html_doc,encoding='utf-8')
# run QA of file sizes, data and 2025 void
assert 'not_published_bilateral' in (P/'bilateral_services_singstat_2003_2025.csv').read_text(encoding='utf-8-sig')
with zipfile.ZipFile('/mnt/data/indonesia_singapura_tahap3_jasa_2003_2025.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for f in P.iterdir():
        if f.is_file():z.write(f,'stage3_services/'+f.name)
print('RESULTS:',json.dumps(summary,indent=2))
print('\nFILES:',[(f.name, f.stat().st_size) for f in P.iterdir() if f.is_file()])
