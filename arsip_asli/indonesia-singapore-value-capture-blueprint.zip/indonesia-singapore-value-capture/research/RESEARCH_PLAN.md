# Indonesia–Singapore Economic Value Capture Observatory
## Protokol riset v1.0 — 24 Oktober 2026

### Mandat
Bangun panel historis Indonesia–Singapura dengan data 2003–2025 (2025 hanya jika tersedia dan diberi status resmi/sementara). Publikasikan hasilnya pada website interaktif berbasis HTML yang memungkinkan pembaca menelusuri sumber, metodologi, dan ketidakpastian setiap angka. Catat pula seri yang tersedia sebelum 2003, tanpa memaksakan periode homogen.

### Pertanyaan riset
1. Berapa perdagangan, investasi, jasa dan keterkaitan ekonomi dua negara per tahun?
2. Berapa nilai tambah yang *diciptakan di Singapura* dan terkait permintaan/input Indonesia?
3. Berapa pendapatan investasi akibat aktivitas Indonesia yang diatribusikan ke investor Singapura?
4. Sektor, komoditas, dan korporasi apa yang menjelaskan pola tersebut?
5. Siapa penerima manfaat akhir setelah menelusuri rantai kepemilikan?
6. Apakah perubahan tahunan terjadi karena kuantitas, harga, nilai tambah, perubahan struktur kepemilikan, atau perubahan metode statistik?

### Definisi dan larangan agregasi
- Exposure: nilai perdagangan, pendapatan jasa bruto, stok dan arus investasi. BUKAN laba.
- Singapore domestic value added attributable to Indonesia: nilai tambah aktivitas di wilayah Singapura yang ditelusuri melalui model input-output, atau metode mikro yang sesuai.
- Investment income arising from Indonesia: pendapatan ekuitas/bunga oleh investor nonresiden; pisahkan dividen, laba ditahan, bunga.
- Ultimate beneficiary: bagian pendapatan/hak ekonomi yang berujung kepada pemilik akhir, bukan otomatis domicile holding company.
- Tidak menjumlahkan ekspor bruto + nilai tambah + dividen dari aktivitas yang sama.
- Tidak menjumlahkan seluruh dividen dengan laba total jika dividen merupakan bagian laba total.
- Tidak menyamakan stok FDI, realisasi investasi, dan laba tahunan.
- Tidak menyamakan GNI (termasuk pendapatan neto dari luar negeri) dengan GDP (nilai tambah domestik).
- Tidak menyebut seluruh pendapatan Singapura sebagai kerugian Indonesia.

### Paket kerja
WP01 — Perdagangan barang: bilateral export/import FOB/CIF, trade mirror, kategori HS/SITC, volume dan harga unit. Baseline 2003–2025.
WP02 — Komoditas & re-export: sawit, batubara, minyak, nikel (cakupan disesuaikan saat verifikasi). Pisahkan re-export fisik, merchanting dan transshipment. Jangan klaim margin tanpa informasi biaya.
WP03 — FDI: outward Singapore to Indonesia dan inward Indonesia from Singapore; stock/flow/income/debt vs equity; immediate vs ultimate investor; bedakan cakupan BKPM/BPS dan BoP.
WP04 — Jasa: Indonesia membeli jasa Singapura, kategori financial/travel/transport/business/ICT dan estimasi nilai tambah (jangan samakan revenue dengan profit).
WP05 — OECD TiVA/ICIO: nilai tambah domestik Singapura yang embodied dalam perdagangan dan final demand terkait Indonesia. Seri 1995–2022 untuk edisi 2025.
WP06 — Corporate: laporan keuangan, laba segmen, dividen, aset per negara, pajak, related-party, anak perusahaan dan ultimate parent.
WP07 — Finance/capital markets: bunga, portfolio position/income bila tersedia secara bilateral, banking & market service fees, fund domicile.
WP08 — Beneficial ownership dan peluang retensi nilai: peta ownership, analisis kontrafaktual realistis terhadap biaya dan kemampuan industri.

### Sumber inti
- SingStat FDI stock destination: https://data.gov.sg/datasets/d_a1db0947cc69ae27d0ffb6ddfaf6cdde/view
- SingStat FDI stock destination x industry: https://data.gov.sg/datasets/d_dea084e8924680c954f1569a27f6d96c/view
- SingStat Table Builder/API: https://www.singstat.gov.sg/tablebuilder
- SingStat merchandise methodology (FOB/CIF/re-export): https://www.singstat.gov.sg/find-data/explore-data-themes/trade-investment/merchandise-trade/our-data-explained
- BI SEKI: https://www.bi.go.id/id/statistik/ekonomi-keuangan/seki/default.aspx
- IMF DIP: https://data.imf.org/Datasets/DIP
- OECD ICIO: https://www.oecd.org/en/data/datasets/inter-country-input-output-tables.html
- OECD TiVA: https://www.oecd.org/en/topics/sub-issues/trade-in-value-added.html
- BPS FDI realization: https://www.bps.go.id/en/statistics-table/2/MTg0MyMy/realisasi-investasi-
- UN Comtrade: https://comtradeplus.un.org/

### Source quality protocol
1. Rekam URL resmi, tabel/seri, metode statistik, tahun, tanggal unduh, perubahan versi dan pembatasan lisensi.
2. Simpan file mentah tak diubah (raw) dan hash SHA256.
3. Konversi setiap indikator ke struktur panjang (tidy) dan simpan nilai aslinya dalam mata uang asli.
4. Buat versi USD nominal dan versi riil hanya jika definisi deflator dan FX jelas; simpan transformasi terpisah.
5. Uji mirror: Indonesia exports vs Singapore imports; Singapura exports vs Indonesia imports; catat CIF/FOB, re-export, timing, origin/destination dan cakupan.
6. Bedakan 'observed official', 'audited/company filing', 'modelled estimate', 'scenario', dan 'not available'.
7. Untuk data estimasi: metode, input, asumsi, sensitivitas, rentang hasil dan reviewer wajib tersedia.
8. Publikasi setiap chart disertai sumber, definisi, status dan catatan keterbatasan.
9. Tidak mengisi kekosongan dengan nol atau interpolasi tanpa penandaan jelas.
10. Source tables berarah: `Singapore outward investment in Indonesia` dan `foreign investment into Singapore from Indonesia` tidak saling menggantikan.

### Dataset standar
Gunakan `data/observation_schema.json` dan `data/source_registry.json`. Minimal grain = observation per year x metric x country_direction x sector x source. Data tersedia sebagai berkas statis `/public/data/*.json` untuk website. Raw data disimpan di luar bundle website.

### Rencana halaman website
`/` Executive Dashboard; `/timeline` yearly trends; `/trade` barang; `/commodities` case studies; `/investments` FDI & investment income; `/services` jasa; `/value-added` ICIO/TiVA; `/companies` pemilik & kinerja; `/methods` data & audit trail; `/sources` dataset registry.

### Visualisasi inti
- Year slider 2003–2025; semua grafik menunjukkan rentang ketersediaan nyata.
- Multiline ekspor/impor/FDI/services; selector USD/SGD dengan provenance FX.
- Stacked sector view; waterfall untuk nilai tambah hanya pada komponen yang compatible.
- Sankey terpisah untuk flow komoditas versus income ownership; tidak mencampur flow fisik dan kepemilikan.
- Drilldown chart -> observation -> sumber resmi/perusahaan -> halaman/metode.
- Panel 'belum tersedia' untuk indikator yang belum dapat dihitung.

### Acceptance criteria
- Semua angka website bersumber dari satu observation ID yang memuat provenance.
- Semua grafik dapat diunduh beserta dataset terfilter.
- 100% observasi 'modelled' mempunyai metode dan rentang/analisis sensitivitas.
- Tidak ada double counting dalam angka agregat.
- Peringatan jelas atas data sementara, perubahan metodologi, dan estimasi tidak final.
- Website tetap bisa memuat data baru tanpa perubahan konten HTML statis per tahun.

### Sprint awal
A. Tarik seluruh baris Indonesia dari SingStat M084431 (stok FDI), jasa bilateral dan perdagangan tahunan.
B. Tarik padanan dari BI/BPS dan identifikasi keterbandingannya.
C. Bangun research source registry dan data dictionary.
D. Hasilkan 3 grafik validasi (FDI stok; jasa bilateral; perdagangan barang) dengan sumber per titik.
E. Setelah baseline valid, lanjutkan OECD ICIO, perusahaan, dan ownership.
