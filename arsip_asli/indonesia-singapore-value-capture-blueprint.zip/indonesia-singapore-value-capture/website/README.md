# Target HTML Observatory (not built yet)

Use the research validated JSON tables for a static-first website. Initial page structure:
- `/` dashboard
- `/timeline` chronological series
- `/trade` bilateral trade mirror
- `/commodities` commodity pathways
- `/investments` FDI stock vs flows vs income
- `/services` international services
- `/value-added` OECD ICIO/TiVA
- `/companies` company and ownership research
- `/methods` methodology, units, deflators, known gaps
- `/sources` source links, download/version metadata

Architecture target: semantic HTML frontend + JS charts + accessible data tables + JSON static data. No unreviewed AI-generated claim or value enters final charts. Git tracks source schema/transforms; large originals stored in controlled raw archive.
